using FallenSpoofer.Spoofers;
using Xunit;

namespace FallenSpoofer.Tests
{
    public class HardwareRandomizerTests
    {
        [Fact]
        public void RandomHex_ReturnsCorrectLength()
        {
            string result = HardwareRandomizer.RandomHex(16);
            Assert.Equal(16, result.Length);
        }

        [Fact]
        public void RandomHex_ContainsOnlyHexCharacters()
        {
            string result = HardwareRandomizer.RandomHex(32);
            Assert.True(System.Text.RegularExpressions.Regex.IsMatch(result, "^[0-9A-F]+$"));
        }

        [Fact]
        public void RandomMacAddress_NoDashes_ReturnsCorrectFormat()
        {
            string result = HardwareRandomizer.RandomMacAddress(dashed: false);
            Assert.Equal(12, result.Length);
            Assert.True(System.Text.RegularExpressions.Regex.IsMatch(result, "^[0-9A-F]{12}$"));
        }

        [Fact]
        public void RandomMacAddress_Dashed_ReturnsCorrectFormat()
        {
            string result = HardwareRandomizer.RandomMacAddress(dashed: true);
            Assert.Equal(17, result.Length);
            Assert.Contains("-", result);
        }

        [Fact]
        public void RandomMacAddress_HasLocallyAdministeredBit()
        {
            string result = HardwareRandomizer.RandomMacAddress(dashed: false);
            byte firstByte = Convert.ToByte(result.Substring(0, 2), 16);
            Assert.True((firstByte & 0x02) != 0, "Should have locally administered bit set");
        }

        [Fact]
        public void RandomUuid_ReturnsValidGuid()
        {
            string result = HardwareRandomizer.RandomUuid();
            Assert.True(Guid.TryParse(result, out _));
        }

        [Fact]
        public void RandomCpuName_ReturnsNonEmptyString()
        {
            string result = HardwareRandomizer.RandomCpuName();
            Assert.False(string.IsNullOrEmpty(result));
        }

        [Fact]
        public void RandomInt_ReturnsValueInRange()
        {
            for (int i = 0; i < 100; i++)
            {
                int result = HardwareRandomizer.RandomInt(10, 20);
                Assert.InRange(result, 10, 19);
            }
        }
    }

    public class SpoofManagerTests
    {
        [Fact]
        public void AddOriginal_AddsNewEntry()
        {
            SpoofManager.Instance.Clear();
            SpoofManager.Instance.AddOriginal("test|key", "value");
            Assert.Equal("value", SpoofManager.Instance.OriginalValues["test|key"]);
        }

        [Fact]
        public void AddOriginal_DoesNotOverwriteExisting()
        {
            SpoofManager.Instance.Clear();
            SpoofManager.Instance.AddOriginal("test|key", "original");
            SpoofManager.Instance.AddOriginal("test|key", "new");
            Assert.Equal("original", SpoofManager.Instance.OriginalValues["test|key"]);
        }

        [Fact]
        public void Clear_RemovesAllEntries()
        {
            SpoofManager.Instance.AddOriginal("test|key1", "value1");
            SpoofManager.Instance.AddOriginal("test|key2", "value2");
            SpoofManager.Instance.Clear();
            Assert.Empty(SpoofManager.Instance.OriginalValues);
        }

        [Fact]
        public void ExportBackup_ReturnsValidJson()
        {
            SpoofManager.Instance.Clear();
            SpoofManager.Instance.AddOriginal("test|key", "value");
            string json = SpoofManager.Instance.ExportBackup();
            Assert.NotNull(json);
            Assert.Contains("test|key", json);
        }

        [Fact]
        public void ImportBackup_ReturnsDictionary()
        {
            string json = "{\"test|key\":\"value\"}";
            var dict = SpoofManager.Instance.ImportBackup(json);
            Assert.NotNull(dict);
            Assert.Equal("value", dict["test|key"]);
        }
    }

    public class LoggerTests
    {
        [Fact]
        public void Initialize_CreatesLogFile()
        {
            string tempDir = Path.Combine(Path.GetTempPath(), $"FallenSpoofer_Test_{Guid.NewGuid():N}");
            Directory.CreateDirectory(tempDir);

            Logger.Initialize(tempDir);
            Logger.Info("Test message");

            var logFiles = Directory.GetFiles(tempDir, "*.log");
            Assert.NotEmpty(logFiles);

            Cleanup(tempDir);
        }

        private void Cleanup(string dir)
        {
            try { Directory.Delete(dir, true); } catch { }
        }
    }

    public class SpoofModuleTests
    {
        [Fact]
        public void ValidateRegistryPath_Null_ReturnsFalse()
        {
            var module = new TestSpoofModule();
            Assert.False(module.ValidateRegistryPath(null));
        }

        [Fact]
        public void ValidateRegistryPath_Empty_ReturnsFalse()
        {
            var module = new TestSpoofModule();
            Assert.False(module.ValidateRegistryPath(""));
        }

        [Fact]
        public void ValidateRegistryPath_TooLong_ReturnsFalse()
        {
            var module = new TestSpoofModule();
            Assert.False(module.ValidateRegistryPath(new string('A', 300)));
        }

        [Fact]
        public void ValidateMacAddress_ValidDashed_ReturnsTrue()
        {
            var module = new TestSpoofModule();
            Assert.True(module.ValidateMacAddress("AA-BB-CC-DD-EE-FF"));
        }

        [Fact]
        public void ValidateMacAddress_InvalidFormat_ReturnsFalse()
        {
            var module = new TestSpoofModule();
            Assert.False(module.ValidateMacAddress("AABBCCDDEEFF"));
        }

        private class TestSpoofModule : SpoofModule
        {
            public override string Name => "Test";
            public override string Description => "Test module";
            public override Task ExecuteAsync() => Task.CompletedTask;
        }
    }
}
