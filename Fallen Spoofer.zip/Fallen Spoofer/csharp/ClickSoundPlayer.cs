using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using FallenSpoofer.Spoofers;

namespace FallenSpoofer
{
    public static class ClickSoundPlayer
    {
        private static string tempFilePath = null;

        [DllImport("winmm.dll", CharSet = CharSet.Unicode)]
        private static extern int mciSendString(string command, StringBuilder buffer, int bufferSize, IntPtr callback);

        private static string EnsureTempFile()
        {
            if (tempFilePath != null && File.Exists(tempFilePath))
                return tempFilePath;

            try
            {
                var assembly = Assembly.GetExecutingAssembly();
                using (var stream = assembly.GetManifestResourceStream("FallenSpoofer.ClickSound.mp3"))
                {
                    if (stream == null)
                    {
                        Debug.WriteLine("ClickSound: Resource not found");
                        return null;
                    }

                    tempFilePath = Path.Combine(Path.GetTempPath(), $"FallenSpoofer_Click_{Guid.NewGuid():N}.mp3");
                    using (var fileStream = File.Create(tempFilePath))
                    {
                        stream.CopyTo(fileStream);
                    }
                }
                return tempFilePath;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ClickSound: Failed to extract resource: {ex.Message}");
                return null;
            }
        }

        private static readonly string Alias = "FallenSpooferClick";

        public static void Play()
        {
            try
            {
                string filePath = EnsureTempFile();
                if (filePath == null) return;

                mciSendString($"close {Alias}", null, 0, IntPtr.Zero);

                string openCmd = $"open \"{filePath}\" type mpegvideo alias {Alias}";
                string playCmd = $"play {Alias} from 0";

                mciSendString(openCmd, null, 0, IntPtr.Zero);
                mciSendString(playCmd, null, 0, IntPtr.Zero);
            }
            catch (Exception ex)
            {
                Logger.Debug($"ClickSound: Play failed: {ex.Message}");
            }
        }

        public static void Cleanup()
        {
            try
            {
                mciSendString($"close {Alias}", null, 0, IntPtr.Zero);

                if (tempFilePath != null && File.Exists(tempFilePath))
                {
                    File.Delete(tempFilePath);
                    tempFilePath = null;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ClickSound: Cleanup failed: {ex.Message}");
            }
        }
    }
}
