using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using FallenSpoofer.Spoofers;

namespace FallenSpoofer
{
    public static class AutoUpdateChecker
    {
        private static readonly string appDataFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FallenSpoofer");
        private static readonly string VersionFile = Path.Combine(appDataFolder, "version.json");
        private static readonly string RemoteVersionUrl = "https://raw.githubusercontent.com/Casual0developer/Fallen-Spoofer/main/Version";
        private static readonly string ReleasesUrl = "https://github.com/Casual0developer/Fallen-Spoofer";
        public static readonly Version CurrentVersion = new Version(1, 0, 8);
        private static readonly HttpClient HttpClient;

        static AutoUpdateChecker()
        {
            var handler = new HttpClientHandler
            {
                MaxConnectionsPerServer = 2
            };
            HttpClient = new HttpClient(handler);
            HttpClient.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", "FallenSpoofer/1.0.8");
            HttpClient.Timeout = TimeSpan.FromSeconds(10);
        }

        public static void Dispose()
        {
            HttpClient?.Dispose();
        }

        public static async Task<UpdateInfo> CheckForUpdateAsync(CancellationToken ct = default)
        {
            try
            {
                SaveLocalVersion();

                var cacheBuster = $"?t={DateTimeOffset.UtcNow.ToUnixTimeSeconds()}";
                var response = await HttpClient.GetAsync(RemoteVersionUrl + cacheBuster, ct);
                Debug.WriteLine($"Update check: HTTP {(int)response.StatusCode}");
                if (!response.IsSuccessStatusCode)
                {
                    return new UpdateInfo { HasUpdate = false };
                }

                string remoteVersionStr = (await response.Content.ReadAsStringAsync(ct)).Trim();
                Debug.WriteLine($"Update check: Remote version text = '{remoteVersionStr}'");

                if (string.IsNullOrEmpty(remoteVersionStr))
                {
                    Debug.WriteLine("Update check: Empty response");
                    return new UpdateInfo { HasUpdate = false };
                }

                remoteVersionStr = remoteVersionStr.Split('\n')[0].Trim();

                if (!Version.TryParse(remoteVersionStr, out Version remoteVersion))
                {
                    Debug.WriteLine($"Update check: Cannot parse version: {remoteVersionStr}");
                    return new UpdateInfo { HasUpdate = false };
                }

                if (remoteVersion > CurrentVersion)
                {
                    return new UpdateInfo
                    {
                        HasUpdate = true,
                        CurrentVersion = CurrentVersion.ToString(),
                        LatestVersion = remoteVersion.ToString(),
                        DownloadUrl = ReleasesUrl
                    };
                }

                return new UpdateInfo { HasUpdate = false };
            }
            catch (OperationCanceledException)
            {
                return new UpdateInfo { HasUpdate = false };
            }
            catch (HttpRequestException ex)
            {
                Debug.WriteLine($"Update check network error: {ex.Message}");
                return new UpdateInfo { HasUpdate = false };
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Update check failed: {ex.GetType().Name}: {ex.Message}");
                return new UpdateInfo { HasUpdate = false };
            }
        }

        private static void SaveLocalVersion()
        {
            try
            {
                Directory.CreateDirectory(appDataFolder);
                var versionData = new VersionData
                {
                    Version = CurrentVersion.ToString(),
                    LastCheck = DateTime.UtcNow.ToString("o")
                };
                string json = JsonSerializer.Serialize(versionData, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(VersionFile, json);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Save version failed: {ex.Message}");
            }
        }

        public static void OpenReleasesPage()
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = ReleasesUrl,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Open releases failed: {ex.Message}");
            }
        }

        private static readonly List<LogEntry> pendingMessages = new List<LogEntry>();
        private static readonly object messageLock = new object();
        public static bool HasUpdateAvailable { get; private set; } = false;
        public static string LatestVersionString { get; private set; } = "";

        public static async Task ShowUpdateNotificationAsync(IProgress<LogEntry> logProgress, Color accentColor, Color successColor)
        {
            lock (messageLock)
            {
                pendingMessages.Clear();
                HasUpdateAvailable = false;
                LatestVersionString = "";
            }
            try
            {
                var msgChecking = new LogEntry("[*] Checking for updates...", Color.Gray);
                lock (messageLock) pendingMessages.Add(msgChecking);
                logProgress?.Report(msgChecking);

                using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(15));
                var info = await CheckForUpdateAsync(cts.Token);
                if (info.HasUpdate)
                {
                    lock (messageLock)
                    {
                        HasUpdateAvailable = true;
                        LatestVersionString = info.LatestVersion;
                    }
                    var msg1 = new LogEntry($"[!] Update available: v{info.LatestVersion} (current: v{info.CurrentVersion})", accentColor);
                    var msg2 = new LogEntry($"[*] Download: {info.DownloadUrl}", accentColor);
                    lock (messageLock)
                    {
                        pendingMessages.Add(msg1);
                        pendingMessages.Add(msg2);
                    }
                    logProgress?.Report(msg1);
                    logProgress?.Report(msg2);
                }
                else
                {
                    var msg = new LogEntry($"[+] Running latest version (v{CurrentVersion})", successColor);
                    pendingMessages.Add(msg);
                    logProgress?.Report(msg);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Update notification failed: {ex.Message}");
                var msg = new LogEntry($"[~] Update check failed: {ex.Message}", Color.Gray);
                pendingMessages.Add(msg);
                logProgress?.Report(msg);
            }
        }

        public static List<LogEntry> GetPendingMessages()
        {
            lock (messageLock)
            {
                var messages = new List<LogEntry>(pendingMessages);
                pendingMessages.Clear();
                return messages;
            }
        }
    }

    public class UpdateInfo
    {
        public bool HasUpdate { get; set; }
        public string CurrentVersion { get; set; }
        public string LatestVersion { get; set; }
        public string DownloadUrl { get; set; }
    }

    public class VersionData
    {
        public string Version { get; set; }
        public string LastCheck { get; set; }
    }
}
