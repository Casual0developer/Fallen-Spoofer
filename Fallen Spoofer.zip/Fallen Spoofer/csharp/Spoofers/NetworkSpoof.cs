using System;
using System.Linq;
using System.Net.NetworkInformation;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FallenSpoofer.Spoofers
{
    public class NetworkSpoof : SpoofModule
    {
        private const string NetClass = @"SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}";

        public override string Name => "Network / ARP";
        public override string Description => "Spoof network adapter GUIDs and ARP cache settings";

        public override Task ExecuteAsync()
        {
            Log("[*] Starting network spoofing...");

            if (!IsAdmin())
            {
                Log("[!] Admin required!", ErrorColor);
                return Task.CompletedTask;
            }

            int spoofedAdapters = 0;
            int errors = 0;

            try
            {
                string tcpipPath = @"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters";
                if (ValidateRegistryPath(tcpipPath) && RegistryExists(tcpipPath))
                {
                    try
                    {
                        WriteAndSave(tcpipPath, "Hostname", "DESKTOP-" + RandomHex(7).ToUpper());
                        WriteAndSave(tcpipPath, "NV Hostname", "DESKTOP-" + RandomHex(7).ToUpper());
                        WriteAndSave(tcpipPath, "Domain", "");
                        spoofedAdapters++;
                    }
                    catch (Exception ex)
                    {
                        errors++;
                        Logger.Debug($"TCP/IP params error: {ex.Message}");
                    }
                }

                string tcpip6Path = @"SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters";
                WriteIfExists(tcpip6Path, "Hostname", "DESKTOP-" + RandomHex(7).ToUpper());

                string dhcpPath = @"SYSTEM\CurrentControlSet\Services\Dhcp\Parameters";
                WriteIfExists(dhcpPath, "Hostname", "DESKTOP-" + RandomHex(7).ToUpper());

                for (int i = 0; i < MaxAdapterSlots; i++)
                {
                    CancellationToken.ThrowIfCancellationRequested();

                    try
                    {
                        string netPath = $@"{NetClass}\{i:D4}";
                        if (!ValidateRegistryPath(netPath) || !RegistryExists(netPath)) continue;

                        WriteAndSave(netPath, "NetworkAdapterCMAa", Guid.NewGuid().ToString());
                        WriteAndSave(netPath, "NetCfgInstanceId", "{" + Guid.NewGuid().ToString() + "}");
                        WriteAndSave(netPath, "GUID", "{" + Guid.NewGuid().ToString() + "}");
                        WriteAndSave(netPath, "DriverDesc", "Realtek PCIe GbE Family Controller");
                        WriteAndSave(netPath, "ProviderName", "Microsoft");
                        spoofedAdapters++;
                    }
                    catch (Exception ex)
                    {
                        errors++;
                        Logger.Debug($"Network adapter {i} error: {ex.Message}");
                    }
                }

                string netbtPath = @"SYSTEM\CurrentControlSet\Services\NetBT\Parameters";
                if (ValidateRegistryPath(netbtPath) && RegistryExists(netbtPath))
                {
                    try
                    {
                        string netBIOS = "NET" + RandomHex(5).ToUpper();
                        WriteAndSave(netbtPath, "NameServer", netBIOS);
                        WriteAndSave(netbtPath, "DomainName", netBIOS);
                        WriteAndSave(netbtPath, "EnableProxy", "0");
                        spoofedAdapters++;
                    }
                    catch (Exception ex)
                    {
                        errors++;
                        Logger.Debug($"NetBT error: {ex.Message}");
                    }
                }

                string lanmanPath = @"SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters";
                if (ValidateRegistryPath(lanmanPath) && RegistryExists(lanmanPath))
                {
                    try
                    {
                        WriteAndSave(lanmanPath, "SrvComment", "Server " + RandomHex(4));
                        WriteAndSave(lanmanPath, "ServerName", "NET" + RandomHex(5).ToUpper());
                        spoofedAdapters++;
                    }
                    catch (Exception ex)
                    {
                        errors++;
                        Logger.Debug($"LanmanServer error: {ex.Message}");
                    }
                }

                string dnsPath = @"SYSTEM\CurrentControlSet\Services\Dnscache\Parameters";
                WriteIfExists(dnsPath, "DomainName", "");

                if (spoofedAdapters == 0)
                    Log("[~] No network adapters found", WarnColor);
                else
                    Log($"[+] Network spoofed ({spoofedAdapters} entries, {errors} errors)");
            }
            catch (Exception ex)
            {
                Log($"[!] Network spoof failed: {ex.Message}", ErrorColor);
                Logger.Debug(ex.ToString());
            }

            return Task.CompletedTask;
        }
    }
}
