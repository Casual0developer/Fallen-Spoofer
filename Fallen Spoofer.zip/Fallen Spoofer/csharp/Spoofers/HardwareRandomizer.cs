using System;
using System.Linq;
using System.Security.Cryptography;

namespace FallenSpoofer.Spoofers
{
    public static class HardwareRandomizer
    {
        private static int NextInt(int min, int max)
        {
            byte[] bytes = new byte[4];
            RandomNumberGenerator.Fill(bytes);
            uint value = BitConverter.ToUInt32(bytes, 0);
            return min + (int)(value % (uint)(max - min));
        }

        public static int RandomInt(int min, int max) => NextInt(min, max);

        public static string RandomHex(int length)
        {
            byte[] bytes = RandomNumberGenerator.GetBytes(length / 2 + 1);
            return BitConverter.ToString(bytes).Replace("-", "").Substring(0, length);
        }

        private static string NextHex(int length) => RandomHex(length);

        public static string RandomCpuName()
        {
            string[] intelCores = { "i9", "i7", "i5", "i3" };
            string[] intelGens = { "13900K", "13700K", "13600K", "12900K", "12700K", "12600K", "12400", "12100" };
            string[] ryzenCores = { "Ryzen 9", "Ryzen 7", "Ryzen 5" };
            string[] ryzenGens = { "7950X", "7900X", "7700X", "7600X", "5900X", "5800X", "5600X", "5500" };

            if (NextInt(0, 2) == 0)
                return $"Intel(R) Core(TM) {intelCores[NextInt(0, intelCores.Length)]}-{intelGens[NextInt(0, intelGens.Length)]}";
            else
                return $"AMD {ryzenCores[NextInt(0, ryzenCores.Length)]} {ryzenGens[NextInt(0, ryzenGens.Length)]}";
        }

        public static string RandomGpuName()
        {
            string[] nvidiaCards = { "NVIDIA GeForce RTX 4090", "NVIDIA GeForce RTX 4080", "NVIDIA GeForce RTX 4070 Ti", "NVIDIA GeForce RTX 4070", "NVIDIA GeForce RTX 3090", "NVIDIA GeForce RTX 3080", "NVIDIA GeForce RTX 3070", "NVIDIA GeForce RTX 3060 Ti", "NVIDIA GeForce GTX 1660 SUPER", "NVIDIA GeForce GTX 1080 Ti" };
            string[] amdCards = { "AMD Radeon RX 7900 XTX", "AMD Radeon RX 7900 XT", "AMD Radeon RX 7800 XT", "AMD Radeon RX 7700 XT", "AMD Radeon RX 6950 XT", "AMD Radeon RX 6900 XT", "AMD Radeon RX 6800 XT", "AMD Radeon RX 6700 XT", "AMD Radeon RX 5700 XT", "AMD Radeon RX 580" };
            string[] intelCards = { "Intel(R) UHD Graphics 770", "Intel(R) UHD Graphics 730", "Intel(R) Iris(R) Xe Graphics", "Intel(R) Arc(TM) A770", "Intel(R) Arc(TM) A750" };

            int vendor = NextInt(0, 3);
            if (vendor == 0) return nvidiaCards[NextInt(0, nvidiaCards.Length)];
            else if (vendor == 1) return amdCards[NextInt(0, amdCards.Length)];
            else return intelCards[NextInt(0, intelCards.Length)];
        }

        public static string RandomDiskSerial()
        {
            return NextHex(16).ToUpper();
        }

    public static string RandomUuid()
        {
            byte[] bytes = RandomNumberGenerator.GetBytes(16);
            return new Guid(bytes).ToString();
        }

        public static string RandomMacAddress(bool dashed = false)
        {
            byte[] bytes = RandomNumberGenerator.GetBytes(6);
            bytes[0] = (byte)(bytes[0] & 0xFE);
            bytes[0] = (byte)(bytes[0] | 0x02);
            return dashed ? string.Join("-", bytes.Select(b => b.ToString("X2"))) : string.Join("", bytes.Select(b => b.ToString("X2")));
        }
    }
}

