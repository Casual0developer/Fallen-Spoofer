using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FallenSpoofer.Spoofers
{
    public class USBSpoof : SpoofModule
    {
        private const string UsbClass = @"SYSTEM\CurrentControlSet\Control\Class\{36fc9e60-c465-11cf-8056-444553540000}";

        public override string Name => "USB";
        public override string Description => "Spoof USB controller and device identifiers";

        public override Task ExecuteAsync()
        {
            Log("[*] Starting USB spoofing...");

            if (!IsAdmin())
            {
                Log("[!] Admin required!", ErrorColor);
                return Task.CompletedTask;
            }

            int count = 0;
            int errors = 0;

            try
            {
                for (int i = 0; i < MaxUsbSlots; i++)
                {
                    CancellationToken.ThrowIfCancellationRequested();

                    try
                    {
                        string path = $@"{UsbClass}\{i:D4}";
                        if (!ValidateRegistryPath(path) || !RegistryExists(path))
                            continue;

                        string controller = GetRandomUsbController();
                        string vidPid = $"VID_{RandomHex(4).ToUpper()}&PID_{RandomHex(4).ToUpper()}";

                        WriteAndSave(path, "DriverDesc", controller);
                        WriteAndSave(path, "ProviderName", "Microsoft");
                        WriteAndSave(path, "MatchingDeviceId", $"USB\\{vidPid}");
                        count++;
                    }
                    catch (Exception ex)
                    {
                        errors++;
                        Logger.Debug($"USB controller {i} error: {ex.Message}");
                    }
                }

                string usbEnumPath = @"SYSTEM\CurrentControlSet\Enum\USB";
                using (var enumKey = Registry.LocalMachine.OpenSubKey(usbEnumPath, true))
                {
                    if (enumKey != null)
                    {
                        foreach (var subKeyName in enumKey.GetSubKeyNames())
                        {
                            CancellationToken.ThrowIfCancellationRequested();

                            try
                            {
                                string fullPath = $@"{usbEnumPath}\{subKeyName}";
                                string vidPid = $"VID_{RandomHex(4).ToUpper()}&PID_{RandomHex(4).ToUpper()}";

                                if (ValidateRegistryPath(fullPath) && RegistryExists(fullPath))
                                {
                                    WriteAndSave(fullPath, "DeviceDesc", GetRandomUsbDevice());
                                    WriteAndSave(fullPath, "FriendlyName", GetRandomUsbDevice());
                                    WriteAndSave(fullPath, "HardwareID", $@"USB\{vidPid}&REV_{RandomHex(4).ToUpper()}");
                                    count++;
                                }
                            }
                            catch (Exception ex)
                            {
                                errors++;
                                Logger.Debug($"USB device error: {ex.Message}");
                            }
                        }
                    }
                }

                if (count == 0)
                    Log("[~] No USB devices found", WarnColor);
                else
                    Log($"[+] USB spoofed ({count} devices, {errors} errors)");
            }
            catch (Exception ex)
            {
                Log($"[!] USB spoof failed: {ex.Message}", ErrorColor);
                Logger.Debug(ex.ToString());
            }

            return Task.CompletedTask;
        }

        private string GetRandomUsbController()
        {
            try
            {
                string[] controllers = {
                    "Intel(R) USB 3.20 eXtensible Host Controller - 1.20 (Microsoft)",
                    "AMD USB 3.10 eXtensible Host Controller - 1.10 (Microsoft)",
                    "ASMedia USB3.2 eXtensible Host Controller",
                    "Renesas USB 3.0 Host Controller",
                    "VIA USB 3.0 Host Controller",
                };
                return controllers[HardwareRandomizer.RandomInt(0, controllers.Length)];
            }
            catch
            {
                return "Intel(R) USB 3.20 eXtensible Host Controller";
            }
        }

        private string GetRandomUsbDevice()
        {
            try
            {
                string[] devices = {
                    "USB Composite Device",
                    "USB Input Device",
                    "USB Mass Storage Device",
                    "USB Human Interface Device",
                    "USB Printing Support",
                    "USB Video Device",
                    "Generic USB Hub",
                };
                return devices[HardwareRandomizer.RandomInt(0, devices.Length)];
            }
            catch
            {
                return "USB Composite Device";
            }
        }
    }
}
