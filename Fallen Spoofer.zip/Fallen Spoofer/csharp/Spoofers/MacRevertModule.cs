using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FallenSpoofer.Spoofers
{
    public class MacRevertModule
    {
        private readonly IProgress<LogEntry> progress;
        private readonly Color successColor;
        private readonly Color errorColor;
        private readonly Color warnColor;

        public MacRevertModule(IProgress<LogEntry> progress, Color success, Color error, Color warn)
        {
            this.progress = progress;
            this.successColor = success;
            this.errorColor = error;
            this.warnColor = warn;
        }

        public async Task<bool> RevertMacAddresses(Dictionary<string, string> macKeys, CancellationToken ct)
        {
            bool anySuccess = false;

            foreach (var kvp in macKeys)
            {
                ct.ThrowIfCancellationRequested();

                string nicId = kvp.Key.StartsWith("MAC_") ? kvp.Key.Substring(4) : kvp.Key;
                string originalMac = kvp.Value;

                if (string.IsNullOrEmpty(originalMac) || originalMac.Length != 17)
                {
                    Log($"[!] Invalid stored MAC for {nicId}", warnColor);
                    continue;
                }

                var nic = FindNetworkInterface(nicId);
                if (nic == null)
                {
                    Log($"[!] Could not find adapter for {nicId}", warnColor);
                    continue;
                }

                string adapterName = nic.Name;
                Log($"[*] Restoring MAC for {adapterName}...", warnColor);

                RestoreMacAllLocations(nic, originalMac);

                bool restarted = await TryRestartAdapterAsync(adapterName, ct);
                if (!restarted)
                {
                    Log($"[!] Restart failed, trying alternative...", warnColor);
                    await TryNetshResetAsync(adapterName, ct);
                }

                anySuccess = true;
                Log($"[+] {adapterName} MAC restored", successColor);
            }

            return anySuccess;
        }

        private void RestoreMacAllLocations(NetworkInterface nic, string originalMac)
        {
            try
            {
                string classPath = FindAdapterRegistryPath(nic.Name);
                if (!string.IsNullOrEmpty(classPath))
                {
                    using (var key = Registry.LocalMachine.CreateSubKey(classPath, true))
                    {
                        if (key != null)
                        {
                            key.SetValue("NetworkAddress", originalMac, RegistryValueKind.String);
                        }
                    }
                }
            }
            catch (Exception ex) { Logger.Debug($"Restore class path: {ex.Message}"); }

            try
            {
                string devPath = SpoofModule.FindAdapterDeviceEnumPath(nic);
                if (!string.IsNullOrEmpty(devPath))
                {
                    using (var key = Registry.LocalMachine.CreateSubKey(devPath, true))
                    {
                        if (key != null)
                        {
                            key.SetValue("NetworkAddress", originalMac, RegistryValueKind.String);
                        }
                    }
                }
            }
            catch (Exception ex) { Logger.Debug($"Restore device path: {ex.Message}"); }

            try
            {
                string configPath = $@"SYSTEM\CurrentControlSet\Control\Network\{{4d36e972-e325-11ce-bfc1-08002be10318}}\{nic.Id}\Connection";
                using (var key = Registry.LocalMachine.CreateSubKey(configPath, true))
                {
                    if (key != null)
                    {
                        key.SetValue("MacAddress", originalMac, RegistryValueKind.String);
                    }
                }
            }
            catch (Exception ex) { Logger.Debug($"Restore config path: {ex.Message}"); }
        }

        private NetworkInterface FindNetworkInterface(string nicId)
        {
            string cleanId = nicId.Trim('{', '}');
            foreach (var nic in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.Id.Trim('{', '}').Equals(cleanId, StringComparison.OrdinalIgnoreCase))
                    return nic;
                if (nic.Name.Contains(cleanId, StringComparison.OrdinalIgnoreCase))
                    return nic;
            }
            return null;
        }

        private string FindAdapterRegistryPath(string adapterName)
        {
            string regPath = @"SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}";
            try
            {
                using (var baseKey = Registry.LocalMachine.OpenSubKey(regPath, false))
                {
                    if (baseKey == null) return null;
                    foreach (var subKeyName in baseKey.GetSubKeyNames())
                    {
                        using (var subKey = baseKey.OpenSubKey(subKeyName, false))
                        {
                            var name = subKey?.GetValue("DriverDesc") as string;
                            if (name == adapterName)
                                return $@"{regPath}\{subKeyName}";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Debug($"Find adapter path error: {ex.Message}");
            }
            return null;
        }

        private async Task<bool> TryRestartAdapterAsync(string adapterName, CancellationToken ct)
        {
            try
            {
                Log($"[*] Restarting {adapterName} via netsh...", warnColor);

                var disableResult = await RunCommandAsync("netsh.exe", $"interface set interface \"{adapterName}\" disable", ct);
                if (!disableResult)
                {
                    Log($"[!] Disable failed, trying alternative...", warnColor);
                    await RunCommandAsync("powershell.exe", $"Disable-NetAdapter -Name \"{adapterName}\" -Confirm:$false", ct);
                }

                await Task.Delay(2000, ct);

                var enableResult = await RunCommandAsync("netsh.exe", $"interface set interface \"{adapterName}\" enable", ct);
                if (!enableResult)
                {
                    await RunCommandAsync("powershell.exe", $"Enable-NetAdapter -Name \"{adapterName}\" -Confirm:$false", ct);
                }

                await Task.Delay(3000, ct);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Debug($"Adapter restart error: {ex.Message}");
                return false;
            }
        }

        private async Task<bool> TryNetshResetAsync(string adapterName, CancellationToken ct)
        {
            try
            {
                Log($"[*] Trying reset via PNPUTIL...", warnColor);

                await RunCommandAsync("pnputil.exe", "/restart-device \"@ms_netandisys\"", ct);
                await Task.Delay(2000, ct);

                await RunCommandAsync("netsh.exe", "winsock reset", ct);
                await Task.Delay(1000, ct);

                await RunCommandAsync("netsh.exe", "int ip reset", ct);
                await Task.Delay(2000, ct);

                return true;
            }
            catch (Exception ex)
            {
                Logger.Debug($"Netsh reset error: {ex.Message}");
                return false;
            }
        }

        private async Task<bool> RunCommandAsync(string file, string args, CancellationToken ct)
        {
            try
            {
                var psi = new ProcessStartInfo(file, args)
                {
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    WindowStyle = ProcessWindowStyle.Hidden,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                using (var proc = Process.Start(psi))
                {
                    if (proc == null) return false;
                    await Task.Run(() => proc.WaitForExit(10000), ct);
                    return proc.ExitCode == 0;
                }
            }
            catch (Exception ex)
            {
                Logger.Debug($"Command error ({file}): {ex.Message}");
                return false;
            }
        }

        private void Log(string message, Color color)
        {
            try
            {
                progress?.Report(new LogEntry(message, color));
            }
            catch (Exception ex)
            {
                Logger.Debug($"Log error: {ex.Message}");
            }
        }
    }
}

