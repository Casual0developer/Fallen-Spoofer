using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FallenSpoofer.Spoofers
{
    public class MainboardSpoof : SpoofModule
    {
        private const string BiosPath = @"HARDWARE\DESCRIPTION\System\BIOS";
        private const string SysInfoPath = @"SYSTEM\CurrentControlSet\Control\SystemInformation";

        public override string Name => "Motherboard / BIOS";
        public override string Description => "Spoof motherboard and BIOS information";

        public override Task ExecuteAsync()
        {
            Log("[*] Starting motherboard spoofing...");

            if (!IsAdmin())
            {
                Log("[!] Admin required!", ErrorColor);
                return Task.CompletedTask;
            }

            if (!ValidateRegistryPath(BiosPath) || !RegistryExists(BiosPath))
            {
                Log("[!] BIOS registry path not found", ErrorColor);
                return Task.CompletedTask;
            }

            int count = 0;
            int errors = 0;

            try
            {
                string[] manufacturers = { "ASUSTeK COMPUTER INC.", "Micro-Star International Co., Ltd.", "Gigabyte Technology Co., Ltd.", "ASRock", "Dell Inc.", "HP", "Lenovo" };
                string[] boards = { "ROG STRIX Z790-E GAMING WIFI", "MAG B760M MORTAR WIFI", "Z790 AORUS ELITE AX", "B650M Pro RS", "OptiPlex 7090", "ProDesk 400 G7", "ThinkCentre M70q" };

                string manufacturer = manufacturers[HardwareRandomizer.RandomInt(0, manufacturers.Length)];
                string board = boards[HardwareRandomizer.RandomInt(0, boards.Length)];
                string serial = RandomHex(12).ToUpper();
                string assetTag = RandomHex(8).ToUpper();

                WriteAndSave(BiosPath, "BaseBoardManufacturer", manufacturer);
                WriteAndSave(BiosPath, "BaseBoardProduct", board);
                WriteAndSave(BiosPath, "BaseBoardVersion", $"Rev 1.{HardwareRandomizer.RandomInt(0, 10)}x");
                WriteAndSave(BiosPath, "BaseBoardSerialNumber", serial);
                WriteAndSave(BiosPath, "BaseBoardAssetTag", assetTag);
                WriteAndSave(BiosPath, "SystemManufacturer", manufacturer);
                WriteAndSave(BiosPath, "SystemProductName", board);
                WriteAndSave(BiosPath, "SystemVersion", "System Version");
                WriteAndSave(BiosPath, "SystemSKU", $"SKU-{RandomHex(6).ToUpper()}");
                WriteAndSave(BiosPath, "SystemSerialNumber", serial);
                WriteAndSave(BiosPath, "SystemFamily", "To be filled by O.E.M.");
                WriteAndSave(BiosPath, "BIOSVendor", "American Megatrends International, LLC.");
                WriteAndSave(BiosPath, "BIOSVersion", $"{HardwareRandomizer.RandomInt(1, 10)}.{HardwareRandomizer.RandomInt(0, 50)}.{HardwareRandomizer.RandomInt(0, 50)}");
                WriteAndSave(BiosPath, "BIOSReleaseDate", GenerateRandomDate());
                WriteAndSave(BiosPath, "BIOSMajorRelease", HardwareRandomizer.RandomInt(1, 15).ToString());
                WriteAndSave(BiosPath, "BIOSMinorRelease", HardwareRandomizer.RandomInt(0, 50).ToString());
                WriteAndSave(BiosPath, "ECFirmwareMajorRelease", HardwareRandomizer.RandomInt(1, 5).ToString());
                WriteAndSave(BiosPath, "ECFirmwareMinorRelease", HardwareRandomizer.RandomInt(0, 10).ToString());
                WriteAndSave(BiosPath, "ChassisManufacturer", manufacturer);
                WriteAndSave(BiosPath, "ChassisType", $"{HardwareRandomizer.RandomInt(1, 15)}");
                WriteAndSave(BiosPath, "ChassisVersion", $"Rev 1.{HardwareRandomizer.RandomInt(0, 10)}x");
                WriteAndSave(BiosPath, "ChassisSerialNumber", serial);
                WriteAndSave(BiosPath, "ChassisAssetTag", assetTag);
                WriteAndSave(BiosPath, "CacheVersion", $"Rev 1.{HardwareRandomizer.RandomInt(0, 10)}");
                WriteAndSave(BiosPath, "CacheSerialNumber", RandomHex(8).ToUpper());

                using (var key = Registry.LocalMachine.OpenSubKey(BiosPath, true))
                {
                    if (key != null)
                    {
                        key.SetValue("SystemBiosDate", GenerateRandomDate(), RegistryValueKind.String);
                        key.SetValue("SystemBiosVersion", $"{RandomHex(4)}.{RandomHex(4)}", RegistryValueKind.String);
                    }
                }

                if (ValidateRegistryPath(SysInfoPath) && RegistryExists(SysInfoPath))
                {
                    WriteAndSave(SysInfoPath, "SystemManufacturer", manufacturer);
                    WriteAndSave(SysInfoPath, "SystemProductName", board);
                }

                count = 25;
                Log($"[+] Motherboard spoofed ({count} values)");
            }
            catch (Exception ex)
            {
                Log($"[!] Motherboard spoof failed: {ex.Message}", ErrorColor);
                Logger.Debug(ex.ToString());
            }

            return Task.CompletedTask;
        }

        private string GenerateRandomDate()
        {
            try
            {
                int year = DateTime.Today.Year - HardwareRandomizer.RandomInt(1, 5);
                int month = HardwareRandomizer.RandomInt(1, 13);
                int daysInMonth = DateTime.DaysInMonth(year, month);
                int day = HardwareRandomizer.RandomInt(1, daysInMonth + 1);
                return $"{month:D2}/{day:D2}/{year}";
            }
            catch
            {
                return DateTime.Today.ToString("MM/dd/yyyy");
            }
        }
    }
}
