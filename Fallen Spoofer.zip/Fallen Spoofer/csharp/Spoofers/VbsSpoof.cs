using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FallenSpoofer.Spoofers
{
    public class VbsSpoof : SpoofModule
    {
        public override string Name => "VBS / Security";
        public override string Description => "Spoof Virtualization-Based Security identifiers";

        public override Task ExecuteAsync()
        {
            Log("[*] Starting VBS identifier spoofing...");

            if (!IsAdmin())
            {
                Log("[!] Admin required!", ErrorColor);
                return Task.CompletedTask;
            }

            int count = 0;

            try
            {
                string deviceGuard = @"SYSTEM\CurrentControlSet\Control\DeviceGuard";
                if (ValidateRegistryPath(deviceGuard) && RegistryExists(deviceGuard))
                {
                    WriteAndSave(deviceGuard, "DeviceGuardEnabled", RandomHex(4).ToUpper());
                    count++;
                }

                string hvci = @"SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity";
                if (ValidateRegistryPath(hvci) && RegistryExists(hvci))
                {
                    WriteAndSave(hvci, "HVCIEnabled", 0);
                    WriteAndSave(hvci, "HVCILocked", 0);
                    count += 2;
                }

                string systemInfo = @"SYSTEM\CurrentControlSet\Control\SystemInformation";
                if (ValidateRegistryPath(systemInfo) && RegistryExists(systemInfo))
                {
                    WriteAndSave(systemInfo, "ComputerHardwareId", "{" + Guid.NewGuid().ToString().ToUpper() + "}");
                    WriteAndSave(systemInfo, "SystemProductName", "System Product Name");
                    WriteAndSave(systemInfo, "SystemManufacturer", "System Manufacturer");
                    count += 3;
                }

                string secureBoot = @"SYSTEM\CurrentControlSet\Control\SecureBoot\State";
                if (ValidateRegistryPath(secureBoot) && RegistryExists(secureBoot))
                {
                    WriteAndSave(secureBoot, "UEFISecureBootEnabled", 0);
                    count++;
                }

                Log($"[+] VBS identifiers spoofed ({count} values)");
            }
            catch (Exception ex)
            {
                Log($"[!] VBS spoof failed: {ex.Message}", ErrorColor);
            }

            return Task.CompletedTask;
        }
    }
}
