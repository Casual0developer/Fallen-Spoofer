using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FallenSpoofer.Spoofers
{
    public class MemorySpoof : SpoofModule
    {
        public override string Name => "Memory";
        public override string Description => "Spoof RAM module identifiers and SMBIOS memory data";

        public override Task ExecuteAsync()
        {
            Log("[*] Starting memory spoofing...");

            if (!IsAdmin())
            {
                Log("[!] Admin required!", ErrorColor);
                return Task.CompletedTask;
            }

            int count = 0;
            int errors = 0;

            try
            {
                string[] memoryPaths = {
                    @"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management",
                    @"SYSTEM\CurrentControlSet\Control\BIOSInformation",
                    @"SYSTEM\CurrentControlSet\Control\SystemInformation",
                };

                foreach (var path in memoryPaths)
                {
                    if (WriteIfExists(path, "Identifier", $"Memory {RandomHex(8).ToUpper()}"))
                        count++;
                }

                string[] memoryTypes = { "DDR4", "DDR5", "DDR3", "LPDDR4", "LPDDR5" };
                string memoryType = memoryTypes[HardwareRandomizer.RandomInt(0, memoryTypes.Length)];
                string capacity = (HardwareRandomizer.RandomInt(4, 65) * 1024).ToString();

                for (int slot = 0; slot < MaxMemorySlots; slot++)
                {
                    CancellationToken.ThrowIfCancellationRequested();

                    try
                    {
                        string tagPath = $@"SYSTEM\CurrentControlSet\Enum\ACPI\Memory Device {slot}";
                        if (ValidateRegistryPath(tagPath) && RegistryExists(tagPath))
                        {
                            WriteAndSave(tagPath, "DeviceDesc", $"{memoryType} SDRAM");
                            WriteAndSave(tagPath, "Slot", slot.ToString());
                            WriteAndSave(tagPath, "Capacity", capacity);
                            WriteAndSave(tagPath, "Speed", (HardwareRandomizer.RandomInt(2133, 6400)).ToString());
                            count++;
                        }
                    }
                    catch (Exception ex)
                    {
                        errors++;
                        Logger.Debug($"Memory slot {slot} error: {ex.Message}");
                    }
                }

                string biosPath = @"HARDWARE\DESCRIPTION\System\BIOS";
                if (ValidateRegistryPath(biosPath) && RegistryExists(biosPath))
                {
                    WriteAndSave(biosPath, "SystemBiosDate", DateTime.Today.AddDays(-HardwareRandomizer.RandomInt(30, 365)).ToString("MM/dd/yyyy"));
                    WriteAndSave(biosPath, "SystemBiosVersion", $"{RandomHex(4)}.{RandomHex(4)}");
                    count++;
                }

                string smBiosPath = @"SYSTEM\CurrentControlSet\Services\mssmbios\Data";
                if (WriteIfExists(smBiosPath, "BiosVersion", "1.0"))
                    count++;

                if (count == 0)
                    Log("[~] No memory paths found", WarnColor);
                else
                    Log($"[+] Memory spoofed ({count} entries, {errors} errors)");
            }
            catch (Exception ex)
            {
                Log($"[!] Memory spoof failed: {ex.Message}", ErrorColor);
                Logger.Debug(ex.ToString());
            }

            return Task.CompletedTask;
        }
    }
}
