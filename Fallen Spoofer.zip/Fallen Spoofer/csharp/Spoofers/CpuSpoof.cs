using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FallenSpoofer.Spoofers
{
    public class CpuSpoof : SpoofModule
    {
        public override string Name => "CPU";
        public override string Description => "Spoof CPU information including name, identifier, vendor, and clock speed";

        public override Task ExecuteAsync()
        {
            Log("[*] Starting CPU spoofing...");

            if (!IsAdmin())
            {
                Log("[!] Admin required!", ErrorColor);
                return Task.CompletedTask;
            }

            try
            {
                string cpuName = HardwareRandomizer.RandomCpuName();
                string cpuId = GenerateCpuId(cpuName);
                string vendorId = GetVendorId(cpuName);
                string clockSpeed = NextClockSpeed(cpuName).ToString();

                int spoofedCores = 0;
                int errorCores = 0;

                for (int i = 0; i < MaxAdapterSlots; i++)
                {
                    CancellationToken.ThrowIfCancellationRequested();

                    string corePath = $@"HARDWARE\DESCRIPTION\System\CentralProcessor\{i}";
                    if (!ValidateRegistryPath(corePath) || !RegistryExists(corePath))
                        continue;

                    try
                    {
                        WriteAndSave(corePath, "ProcessorNameString", cpuName);
                        WriteAndSave(corePath, "Identifier", cpuId);
                        WriteAndSave(corePath, "VendorIdentifier", vendorId);
                        WriteAndSave(corePath, "~MHz", clockSpeed);
                        WriteAndSave(corePath, "ProcessorNameString", cpuName);

                        using (var key = Registry.LocalMachine.OpenSubKey(corePath, true))
                        {
                            if (key != null)
                            {
                                key.SetValue("VendorIdentifier", vendorId, RegistryValueKind.String);
                                key.SetValue("Identifier", cpuId, RegistryValueKind.String);
                                if (i == 0)
                                    key.SetValue("~MHz", clockSpeed, RegistryValueKind.String);
                            }
                        }

                        spoofedCores++;
                    }
                    catch (Exception ex)
                    {
                        errorCores++;
                        Logger.Debug($"CPU core {i} error: {ex.Message}");
                    }
                }

                if (spoofedCores == 0)
                {
                    Log("[!] No CPU core registry keys found", ErrorColor);
                    return Task.CompletedTask;
                }

                Log($"[+] CPU spoofed ({spoofedCores} cores, {errorCores} errors)");
            }
            catch (Exception ex)
            {
                Log($"[!] CPU spoof failed: {ex.Message}", ErrorColor);
                Logger.Debug(ex.ToString());
            }

            return Task.CompletedTask;
        }

        private string GenerateCpuId(string cpuName)
        {
            try
            {
                if (cpuName.StartsWith("Intel"))
                    return $"Intel64 Family 6 Model {HardwareRandomizer.RandomInt(140, 184)} Stepping {HardwareRandomizer.RandomInt(0, 5)}";
                else
                    return $"AMD Model {HardwareRandomizer.RandomInt(1, 25)} Family {HardwareRandomizer.RandomInt(10, 26)}";
            }
            catch (Exception ex)
            {
                Logger.Debug($"GenerateCpuId error: {ex.Message}");
                return "Intel64 Family 6 Model 142 Stepping 12";
            }
        }

        private string GetVendorId(string cpuName)
        {
            try
            {
                if (cpuName.StartsWith("Intel")) return "GenuineIntel";
                if (cpuName.StartsWith("AMD")) return "AuthenticAMD";
                return "GenuineIntel";
            }
            catch (Exception ex)
            {
                Logger.Debug($"GetVendorId error: {ex.Message}");
                return "GenuineIntel";
            }
        }

        private int NextClockSpeed(string cpuName)
        {
            try
            {
                if (cpuName.Contains("i9") || cpuName.Contains("7950") || cpuName.Contains("7900"))
                    return HardwareRandomizer.RandomInt(4500, 5900);
                else if (cpuName.Contains("i7") || cpuName.Contains("7700") || cpuName.Contains("7800") || cpuName.Contains("7900"))
                    return HardwareRandomizer.RandomInt(3500, 5000);
                else if (cpuName.Contains("i5") || cpuName.Contains("7600") || cpuName.Contains("5600") || cpuName.Contains("5800"))
                    return HardwareRandomizer.RandomInt(2500, 4500);
                else
                    return HardwareRandomizer.RandomInt(2000, 3800);
            }
            catch (Exception ex)
            {
                Logger.Debug($"NextClockSpeed error: {ex.Message}");
                return 3600;
            }
        }
    }
}
