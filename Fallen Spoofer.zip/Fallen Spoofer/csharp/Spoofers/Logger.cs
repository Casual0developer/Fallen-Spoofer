using System;
using System.Diagnostics;
using System.IO;

namespace FallenSpoofer.Spoofers
{
    public static class Logger
    {
        private static readonly object Lock = new object();
        private static string LogFilePath;

        public static void Initialize(string logFolder)
        {
            try
            {
                Directory.CreateDirectory(logFolder);
                LogFilePath = Path.Combine(logFolder, $"app_{DateTime.Now:yyyyMMdd}.log");
            }
            catch { }
        }

        public static void Debug(string message) => WriteLog("DBG", message);
        public static void Error(string message) => WriteLog("ERR", message);
        public static void Warning(string message) => WriteLog("WRN", message);
        public static void Info(string message) => WriteLog("INF", message);

        private static void WriteLog(string level, string message)
        {
            try
            {
                string line = $"[{DateTime.Now:HH:mm:ss}] [{level}] {message}";
                System.Diagnostics.Debug.WriteLine(line);
                if (LogFilePath != null)
                {
                    lock (Lock)
                    {
                        File.AppendAllText(LogFilePath, line + Environment.NewLine);
                    }
                }
            }
            catch { }
        }
    }
}
