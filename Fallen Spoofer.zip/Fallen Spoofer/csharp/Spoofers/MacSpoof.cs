using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FallenSpoofer.Spoofers
{
    public class MacSpoof : SpoofModule
    {
        public override string Name => "MAC Addresses";
        public override string Description => "Spoof physical addresses of all network adapters using registry, netsh, and WMI methods";

        [DllImport("iphlpapi.dll", SetLastError = true)]
        static extern int SendARP(uint destIP, uint srcIP, byte[] macAddr, ref int macAddrLen);

        public override async Task ExecuteAsync()
        {
            Log("[*] Starting MAC address spoofing...");

            if (!IsAdmin())
            {
                Log("[!] Admin rights REQUIRED for MAC spoofing!", ErrorColor);
                return;
            }

            var adapters = NetworkInterface.GetAllNetworkInterfaces()
                .Where(nic => nic.OperationalStatus == OperationalStatus.Up &&
                       (nic.NetworkInterfaceType == NetworkInterfaceType.Ethernet ||
                        nic.NetworkInterfaceType == NetworkInterfaceType.Wireless80211))
                .ToList();

            Log($"[*] Found {adapters.Count} active network adapters");

            int count = 0;
            foreach (var nic in adapters)
            {
                CancellationToken.ThrowIfCancellationRequested();

                try
                {
                    string originalMac = FormatMac(nic.GetPhysicalAddress().ToString());
                    if (originalMac.Length != 17)
                    {
                        Log($"[!] {nic.Name}: Invalid MAC, skipping", WarnColor);
                        continue;
                    }

                    string newMac = HardwareRandomizer.RandomMacAddress(dashed: false);
                    Log($"[*] {nic.Name}: {originalMac} -> {newMac}");

                    SpoofManager.Instance.AddOriginal($"MAC_{nic.Id}", originalMac);

                    bool ok = await SpoofMacFullAsync(nic, newMac, originalMac);
                    if (ok)
                    {
                        count++;
                        Log($"[+] {nic.Name} MAC spoofed successfully", SuccessColor);
                    }
                    else
                    {
                        Log($"[-] {nic.Name} failed to spoof", ErrorColor);
                    }
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception ex)
                {
                    Log($"[!] {nic.Name} error: {ex.Message}", ErrorColor);
                    Logger.Debug(ex.ToString());
                }
            }

            SpoofNetBIOS();

            Log($"[+] MAC spoofing complete: {count} adapters changed");
        }

        private async Task<bool> SpoofMacFullAsync(NetworkInterface nic, string newMac, string originalMac)
        {
            bool anySuccess = false;

            if (SetMacViaRegistryClass(nic.Id, newMac)) anySuccess = true;

            if (SetMacViaDeviceInstance(nic, newMac)) anySuccess = true;

            if (SetMacViaNetworkConfig(nic, newMac)) anySuccess = true;

            if (await SetMacViaPowerShellAsync(nic.Name, newMac)) anySuccess = true;

            await RestartAdapterMultipleMethodsAsync(nic.Name);

            return anySuccess;
        }

        private string EscapePowerShellArg(string arg)
        {
            return "'" + arg.Replace("'", "''") + "'";
        }

        private string FormatMac(string raw)
        {
            if (string.IsNullOrEmpty(raw) || raw.Length != 12) return "";
            return $"{raw.Substring(0, 2)}-{raw.Substring(2, 2)}-{raw.Substring(4, 2)}-" +
                   $"{raw.Substring(6, 2)}-{raw.Substring(8, 2)}-{raw.Substring(10, 2)}".ToUpper();
        }

        private bool SetMacViaRegistryClass(string netCfgInstanceId, string mac)
        {
            try
            {
                string regPath = @"SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}";
                using (var baseKey = Registry.LocalMachine.OpenSubKey(regPath, true))
                {
                    if (baseKey == null) return false;

                    foreach (var subKeyName in baseKey.GetSubKeyNames())
                    {
                        using (var subKey = baseKey.OpenSubKey(subKeyName, true))
                        {
                            if (subKey == null) continue;
                            var cfgId = subKey.GetValue("NetCfgInstanceId") as string;
                            if (cfgId != null && string.Equals(cfgId, netCfgInstanceId, StringComparison.OrdinalIgnoreCase))
                            {
                                subKey.SetValue("NetworkAddress", mac, RegistryValueKind.String);
                                return true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Debug($"MAC class registry error: {ex.Message}");
            }
            return false;
        }

        private bool SetMacViaDeviceInstance(NetworkInterface nic, string mac)
        {
            try
            {
                string enumPath = SpoofModule.FindAdapterDeviceEnumPath(nic);
                if (string.IsNullOrEmpty(enumPath)) return false;

                using (var key = Registry.LocalMachine.CreateSubKey(enumPath, true))
                {
                    if (key != null)
                    {
                        key.SetValue("NetworkAddress", mac, RegistryValueKind.String);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Debug($"MAC device instance error: {ex.Message}");
            }
            return false;
        }

        private bool SetMacViaNetworkConfig(NetworkInterface nic, string mac)
        {
            try
            {
                string configPath = $@"SYSTEM\CurrentControlSet\Control\Network\{{4d36e972-e325-11ce-bfc1-08002be10318}}\{nic.Id}\Connection";
                using (var key = Registry.LocalMachine.CreateSubKey(configPath, true))
                {
                    if (key != null)
                    {
                        key.SetValue("MacAddress", mac, RegistryValueKind.String);
                        key.SetValue("PnPCapabilities", 24, RegistryValueKind.DWord);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Debug($"MAC network config error: {ex.Message}");
            }
            return false;
        }

        private async Task<bool> SetMacViaPowerShellAsync(string adapterName, string mac)
        {
            try
            {
                string safeAdapterName = EscapePowerShellArg(adapterName);
                string safeMac = EscapePowerShellArg(mac);
                string psCommand = $"Set-NetAdapter -Name {safeAdapterName} -MacAddress {safeMac} -Confirm:$false -ErrorAction SilentlyContinue";
                bool result = await RunProcessAsync("powershell.exe", $"-Command \"{psCommand}\"", CancellationToken);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Debug($"MAC PowerShell error: {ex.Message}");
                return false;
            }
        }

        private async Task RestartAdapterMultipleMethodsAsync(string adapterName)
        {
            try
            {
                Log($"[*] Restarting {adapterName}...", WarnColor);

                await RunProcessAsync("netsh.exe", $"interface set interface \"{adapterName}\" admin=disable", CancellationToken);
                await Task.Delay(2000, CancellationToken);
                await RunProcessAsync("netsh.exe", $"interface set interface \"{adapterName}\" admin=enable", CancellationToken);
                await Task.Delay(3000, CancellationToken);
            }
            catch (Exception ex)
            {
                Logger.Debug($"Adapter restart error: {ex.Message}");
            }
        }

        private void SpoofNetBIOS()
        {
            try
            {
                string netBIOS = "NET" + RandomHex(5).ToUpper();

                string netbtPath = @"SYSTEM\CurrentControlSet\Services\NetBT\Parameters";
                if (RegistryExists(netbtPath))
                {
                    SafeWrite(netbtPath, "NameServer", netBIOS);
                    SafeWrite(netbtPath, "DomainName", netBIOS);
                    SafeWrite(netbtPath, "EnableProxy", "0");
                }

                string lanmanPath = @"SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters";
                if (RegistryExists(lanmanPath))
                {
                    SafeWrite(lanmanPath, "SrvComment", "Server " + RandomHex(4));
                }

                Log("[+] NetBIOS spoofed", SuccessColor);
            }
            catch (Exception ex)
            {
                Log($"[!] NetBIOS spoof failed: {ex.Message}", ErrorColor);
                Logger.Error(ex.ToString());
            }
        }
    }
}
