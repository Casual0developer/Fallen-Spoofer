using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FallenSpoofer.Spoofers
{
    public class DiskSpoof : SpoofModule
    {
        public override string Name => "Disk Serials";
        public override string Description => "Spoof disk drive serial numbers across multiple controllers";

        public override Task ExecuteAsync()
        {
            Log("[*] Starting disk serial spoofing...");

            if (!IsAdmin())
            {
                Log("[!] Admin required!", ErrorColor);
                return Task.CompletedTask;
            }

            int count = 0;
            int errors = 0;

            try
            {
                for (int port = 0; port < MaxScsiPorts; port++)
                {
                    CancellationToken.ThrowIfCancellationRequested();
                    string scsiPath = $@"HARDWARE\DEVICEMAP\Scsi\Scsi Port {port}\Scsi Bus 0\Target Id 0\Logical Unit Id 0";
                    if (!ValidateRegistryPath(scsiPath) || !RegistryExists(scsiPath)) continue;

                    try
                    {
                        string serial = HardwareRandomizer.RandomDiskSerial();
                        WriteAndSave(scsiPath, "SerialNumber", serial);
                        WriteAndSave(scsiPath, "Identifier", $"Disk {RandomHex(8)}");
                        WriteAndSave(scsiPath, "Type", "Direct-Access Device");
                        count++;
                    }
                    catch (Exception ex)
                    {
                        errors++;
                        Logger.Debug($"SCSI port {port} error: {ex.Message}");
                    }
                }

                for (int port = 0; port < 8; port++)
                {
                    CancellationToken.ThrowIfCancellationRequested();
                    for (int bus = 0; bus < MaxScsiBuses; bus++)
                    {
                        for (int target = 0; target < MaxScsiTargets; target++)
                        {
                            string scsiPath = $@"HARDWARE\DEVICEMAP\Scsi\Scsi Port {port}\Scsi Bus {bus}\Target Id {target}\Logical Unit Id 0";
                            if (!ValidateRegistryPath(scsiPath) || !RegistryExists(scsiPath)) continue;

                            try
                            {
                                string serial = HardwareRandomizer.RandomDiskSerial();
                                WriteAndSave(scsiPath, "SerialNumber", serial);
                                WriteAndSave(scsiPath, "Identifier", $"Disk {RandomHex(8)}");
                                count++;
                            }
                            catch (Exception ex)
                            {
                                errors++;
                                Logger.Debug($"SCSI {port}/{bus}/{target} error: {ex.Message}");
                            }
                        }
                    }
                }

                for (int adapter = 0; adapter < 8; adapter++)
                {
                    for (int controller = 0; controller < 4; controller++)
                    {
                        for (int peripheral = 0; peripheral < 4; peripheral++)
                        {
                            string path = $@"HARDWARE\DESCRIPTION\System\MultifunctionAdapter\{adapter}\DiskController\{controller}\DiskPeripheral\{peripheral}";
                            if (WriteIfExists(path, "Identifier", $"Disk {RandomHex(8)}"))
                                count++;
                        }
                    }
                }

                string[] enumPaths = {
                    @"SYSTEM\CurrentControlSet\Enum\IDE",
                    @"SYSTEM\CurrentControlSet\Enum\SCSI",
                    @"SYSTEM\CurrentControlSet\Enum\STORAGE",
                    @"SYSTEM\CurrentControlSet\Enum\PCI",
                    @"SYSTEM\CurrentControlSet\Enum\USB",
                    @"SYSTEM\CurrentControlSet\Enum\SD",
                };

                foreach (var path in enumPaths)
                {
                    CancellationToken.ThrowIfCancellationRequested();
                    try
                    {
                        if (ValidateRegistryPath(path) && RegistryExists(path))
                        {
                            WriteAndSave(path, "DeviceDesc", "Storage Device");
                            WriteAndSave(path, "Mfg", "Generic");
                            count++;
                        }
                    }
                    catch (Exception ex)
                    {
                        errors++;
                        Logger.Debug($"Enum path {path} error: {ex.Message}");
                    }
                }

                if (count == 0)
                    Log("[~] No disk paths found - spoofing existing paths only", WarnColor);
                else
                    Log($"[+] {count} disk serials spoofed ({errors} errors)");
            }
            catch (Exception ex)
            {
                Log($"[!] Disk spoof failed: {ex.Message}", ErrorColor);
                Logger.Debug(ex.ToString());
            }

            return Task.CompletedTask;
        }
    }
}
