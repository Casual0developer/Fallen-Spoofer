using System;
using System.Drawing;

namespace FallenSpoofer.Spoofers
{
    public struct LogEntry
    {
        public string Message { get; }
        public Color Color { get; }

        public LogEntry(string message, Color color)
        {
            Message = message;
            Color = color;
        }
    }
}
