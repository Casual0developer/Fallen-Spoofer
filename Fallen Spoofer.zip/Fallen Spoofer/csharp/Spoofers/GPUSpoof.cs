using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FallenSpoofer.Spoofers
{
    public class GPUSpoof : SpoofModule
    {
        private const string GpuClass = @"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}";
        private const string MonitorClass = @"SYSTEM\CurrentControlSet\Control\Class\{4d36e96e-e325-11ce-bfc1-08002be10318}";
        private const string DisplayClass = @"SYSTEM\CurrentControlSet\Control\Class\{4d36e96e-e325-11ce-bfc1-08002be10318}";

        public override string Name => "GPU";
        public override string Description => "Spoof GPU information for all graphics adapters";

        public override Task ExecuteAsync()
        {
            Log("[*] Starting GPU spoofing...");

            if (!IsAdmin())
            {
                Log("[!] Admin required!", ErrorColor);
                return Task.CompletedTask;
            }

            int spoofedGpus = 0;
            int spoofedMonitors = 0;
            int errors = 0;

            try
            {
                for (int i = 0; i < 16; i++)
                {
                    CancellationToken.ThrowIfCancellationRequested();

                    try
                    {
                        string gpuPath = $@"{GpuClass}\{i:D4}";
                        if (!ValidateRegistryPath(gpuPath) || !RegistryExists(gpuPath))
                            continue;

                        string gpuName = HardwareRandomizer.RandomGpuName();
                        string provider = GetProviderName(gpuName);
                        string deviceId = GenerateDeviceId(gpuName);
                        string driverVersion = GenerateDriverVersion(gpuName);
                        string driverDate = GenerateDriverDate();

                        WriteAndSave(gpuPath, "DriverDesc", gpuName);
                        WriteAndSave(gpuPath, "ProviderName", provider);
                        WriteAndSave(gpuPath, "MatchingDeviceId", deviceId);
                        WriteAndSave(gpuPath, "DriverVersion", driverVersion);
                        WriteAndSave(gpuPath, "DriverDate", driverDate);
                        WriteAndSave(gpuPath, "Mfg", provider);
                        WriteAndSave(gpuPath, "InfSection", "nvamii_amd64");

                        using (var key = Registry.LocalMachine.OpenSubKey(gpuPath, true))
                        {
                            if (key != null)
                            {
                                key.SetValue("ProviderName", provider, RegistryValueKind.String);
                                key.SetValue("MatchingDeviceId", deviceId, RegistryValueKind.String);
                            }
                        }

                        spoofedGpus++;
                    }
                    catch (Exception ex)
                    {
                        errors++;
                        Logger.Debug($"GPU adapter {i} error: {ex.Message}");
                    }
                }

                for (int i = 0; i < 16; i++)
                {
                    CancellationToken.ThrowIfCancellationRequested();

                    try
                    {
                        string monPath = $@"{MonitorClass}\{i:D4}";
                        if (!ValidateRegistryPath(monPath) || !RegistryExists(monPath))
                            continue;

                        WriteAndSave(monPath, "DriverDesc", "Generic PnP Monitor");
                        WriteAndSave(monPath, "Mfg", "Generic");
                        spoofedMonitors++;
                    }
                    catch (Exception ex)
                    {
                        errors++;
                        Logger.Debug($"Monitor {i} error: {ex.Message}");
                    }
                }

                if (spoofedGpus == 0 && spoofedMonitors == 0)
                {
                    Log("[~] No GPU adapters found", WarnColor);
                }
                else
                {
                    Log($"[+] GPU spoofed ({spoofedGpus} GPUs, {spoofedMonitors} monitors, {errors} errors)");
                }
            }
            catch (Exception ex)
            {
                Log($"[!] GPU spoof failed: {ex.Message}", ErrorColor);
                Logger.Debug(ex.ToString());
            }

            return Task.CompletedTask;
        }

        private string GetProviderName(string gpuName)
        {
            try
            {
                if (gpuName.StartsWith("NVIDIA")) return "NVIDIA";
                if (gpuName.StartsWith("AMD")) return "Advanced Micro Devices, Inc.";
                return "Intel Corporation";
            }
            catch
            {
                return "NVIDIA";
            }
        }

        private string GenerateDeviceId(string gpuName)
        {
            try
            {
                string ven = gpuName.StartsWith("NVIDIA") ? "10DE" : gpuName.StartsWith("AMD") ? "1002" : "8086";
                return $@"PCI\VEN_{ven}&DEV_{RandomHex(4).ToUpper()}&SUBSYS_{RandomHex(8).ToUpper()}";
            }
            catch
            {
                return @"PCI\VEN_10DE&DEV_2684&SUBSYS_00000000";
            }
        }

        private string GenerateDriverVersion(string gpuName)
        {
            try
            {
                if (gpuName.StartsWith("NVIDIA"))
                    return $"31.0.15.{HardwareRandomizer.RandomInt(5100, 5600)}";
                if (gpuName.StartsWith("AMD"))
                    return $"31.0.{HardwareRandomizer.RandomInt(23000, 24000)}.{HardwareRandomizer.RandomInt(100, 300)}";
                return $"31.0.101.{HardwareRandomizer.RandomInt(5000, 6000)}";
            }
            catch
            {
                return "31.0.15.5123";
            }
        }

        private string GenerateDriverDate()
        {
            try
            {
                var dt = DateTime.Today.AddDays(-HardwareRandomizer.RandomInt(30, 365));
                return dt.ToString("MM/dd/yyyy");
            }
            catch
            {
                return DateTime.Today.ToString("MM/dd/yyyy");
            }
        }
    }
}
