using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FallenSpoofer.Spoofers
{
    public abstract class SpoofModule
    {
        public abstract string Name { get; }
        public abstract string Description { get; }

        protected IProgress<LogEntry> Progress { get; private set; }
        protected Color SuccessColor;
        protected Color ErrorColor;
        protected Color WarnColor;
        protected CancellationToken CancellationToken => CancellationTokenSource?.Token ?? CancellationToken.None;
        protected CancellationTokenSource CancellationTokenSource { get; private set; }
        public int SpoofCount;
        public int ErrorCount;

        protected const int MaxRetryCount = 3;
        protected const int RetryBaseDelayMs = 100;
        protected const int MaxRegistryPathLength = 255;
        protected const int MaxHexLength = 128;
        protected const int MaxScsiPorts = 16;
        protected const int MaxScsiBuses = 4;
        protected const int MaxScsiTargets = 4;
        protected const int MaxAdapterSlots = 32;
        protected const int MaxUsbSlots = 16;
        protected const int MaxMemorySlots = 8;
        protected const int ProcessTimeoutMs = 10000;

        public void SetLogging(IProgress<LogEntry> progress, Color success, Color error, Color warn, CancellationTokenSource cts = null)
        {
            Progress = progress;
            SuccessColor = success;
            ErrorColor = error;
            WarnColor = warn;
            CancellationTokenSource = cts;
            SpoofCount = 0;
            ErrorCount = 0;
        }

        protected void Log(string message, Color? color = null)
        {
            try
            {
                Progress?.Report(new LogEntry(message, color ?? Color.Gray));
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Log error: {ex.Message}");
            }
        }

        protected void SaveOriginal(string path, string name)
        {
            try
            {
                using (var key = Registry.LocalMachine.OpenSubKey(path, false))
                {
                    var val = key?.GetValue(name);
                    if (val != null)
                    {
                        string keyName = $"{path}|{name}";
                        SpoofManager.Instance.AddOriginal(keyName, val.ToString() ?? "");
                    }
                }
            }
            catch (Exception ex)
            {
                Log($"[!] SaveOriginal {path}\\{name}: {ex.Message}", ErrorColor);
                Logger.Debug(ex.ToString());
            }
        }

        protected bool SafeWrite(string path, string name, string value, RegistryValueKind kind = RegistryValueKind.String)
        {
            return SafeWriteInternal(path, name, value, kind);
        }

        protected bool SafeWrite(string path, string name, int value, RegistryValueKind kind)
        {
            return SafeWriteInternal(path, name, value, kind);
        }

        private bool SafeWriteInternal(string path, string name, object value, RegistryValueKind kind)
        {
            for (int attempt = 1; attempt <= MaxRetryCount; attempt++)
            {
                try
                {
                    using (var key = Registry.LocalMachine.OpenSubKey(path, true))
                    {
                        if (key != null)
                        {
                            key.SetValue(name, value, kind);
                            SpoofCount++;
                            return true;
                        }
                    }
                }
                catch (UnauthorizedAccessException ex)
                {
                    ErrorCount++;
                    Log($"[!] Access denied: {path}\\{name}", ErrorColor);
                    Logger.Debug(ex.ToString());
                    return false;
                }
                catch (IOException ex) when (attempt < MaxRetryCount)
                {
                    Log($"[!] Transient error (attempt {attempt}/{MaxRetryCount}): {path}\\{name}: {ex.Message}", WarnColor);
                    Logger.Debug(ex.ToString());
                    Thread.Sleep(RetryBaseDelayMs * attempt);
                }
                catch (Exception ex) when (IsTransientException(ex) && attempt < MaxRetryCount)
                {
                    Log($"[!] Transient error (attempt {attempt}/{MaxRetryCount}): {path}\\{name}: {ex.Message}", WarnColor);
                    Logger.Debug(ex.ToString());
                    Thread.Sleep(RetryBaseDelayMs * attempt);
                }
                catch (Exception ex)
                {
                    ErrorCount++;
                    Log($"[!] Write failed: {path}\\{name}: {ex.Message}", ErrorColor);
                    Logger.Debug(ex.ToString());
                    return false;
                }
            }
            return false;
        }

        private static bool IsTransientException(Exception ex)
        {
            if (ex is System.ComponentModel.Win32Exception win32)
            {
                return win32.NativeErrorCode == 5 || win32.NativeErrorCode == 183;
            }
            return ex is IOException || ex is TimeoutException;
        }

        protected void WriteAndSave(string path, string name, string value)
        {
            if (!ValidateRegistryPath(path)) return;
            SaveOriginal(path, name);
            SafeWrite(path, name, value);
        }

        protected void WriteAndSave(string path, string name, int value, RegistryValueKind kind = RegistryValueKind.DWord)
        {
            if (!ValidateRegistryPath(path)) return;
            SaveOriginal(path, name);
            SafeWrite(path, name, value, kind);
        }

        protected bool WriteIfExists(string path, string name, string value)
        {
            if (ValidateRegistryPath(path) && RegistryExists(path))
            {
                WriteAndSave(path, name, value);
                return true;
            }
            return false;
        }

        protected bool WriteIfExists(string path, string name, int value, RegistryValueKind kind = RegistryValueKind.DWord)
        {
            if (ValidateRegistryPath(path) && RegistryExists(path))
            {
                WriteAndSave(path, name, value, kind);
                return true;
            }
            return false;
        }

        protected bool RegistryExists(string path)
        {
            try
            {
                using (var key = Registry.LocalMachine.OpenSubKey(path, false))
                    return key != null;
            }
            catch (Exception ex)
            {
                Logger.Debug($"RegistryExists error: {ex.Message}");
                return false;
            }
        }

        protected string RandomHex(int length)
        {
            if (length <= 0) length = 1;
            if (length > MaxHexLength) length = MaxHexLength;
            return HardwareRandomizer.RandomHex(length);
        }

        protected string GenerateUUID()
        {
            return Guid.NewGuid().ToString();
        }

        protected async Task<bool> RunProcessAsync(string fileName, string arguments, CancellationToken ct = default)
        {
            try
            {
                var psi = new ProcessStartInfo(fileName, arguments)
                {
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                };

                using (var proc = Process.Start(psi))
                {
                    if (proc == null)
                    {
                        Log($"[!] Failed to start: {fileName}", ErrorColor);
                        return false;
                    }

                    var tcs = new TaskCompletionSource<bool>();
                    var waitHandle = new ManualResetEventSlim(false);

                    proc.EnableRaisingEvents = true;
                    proc.Exited += (s, e) => { tcs.TrySetResult(true); waitHandle.Set(); };

                    using (ct.Register(() =>
                    {
                        try { proc.Kill(); }
                        catch (InvalidOperationException) { }
                        catch (System.ComponentModel.Win32Exception) { }
                        tcs.TrySetCanceled();
                        waitHandle.Set();
                    }))
                    {
                        await tcs.Task;
                    }

                    waitHandle.Dispose();

                    if (ct.IsCancellationRequested) return false;

                    return proc.HasExited && proc.ExitCode == 0;
                }
            }
            catch (OperationCanceledException)
            {
                Log($"[!] {fileName} cancelled", WarnColor);
                return false;
            }
            catch (Exception ex)
            {
                Log($"[!] Process {fileName} failed: {ex.Message}", ErrorColor);
                Logger.Debug(ex.ToString());
                return false;
            }
        }

        protected bool IsAdmin()
        {
            try
            {
                var identity = WindowsIdentity.GetCurrent();
                var principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch (Exception ex)
            {
                Logger.Debug($"Admin check error: {ex.Message}");
                return false;
            }
        }

        public bool ValidateRegistryPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) return false;
            if (path.Length > MaxRegistryPathLength) return false;
            return true;
        }

        public bool ValidateMacAddress(string mac)
        {
            if (string.IsNullOrWhiteSpace(mac)) return false;
            return mac.Length == 17 && mac.Count(c => c == '-') == 5;
        }

        public static string FindAdapterDeviceEnumPath(NetworkInterface nic)
        {
            try
            {
                string driverDesc = "";
                string classPath = @"SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}";
                using (var baseKey = Registry.LocalMachine.OpenSubKey(classPath, false))
                {
                    if (baseKey != null)
                    {
                        foreach (var subKeyName in baseKey.GetSubKeyNames())
                        {
                            using (var subKey = baseKey.OpenSubKey(subKeyName, false))
                            {
                                var cfgId = subKey?.GetValue("NetCfgInstanceId") as string;
                                if (cfgId != null && string.Equals(cfgId, nic.Id, StringComparison.OrdinalIgnoreCase))
                                {
                                    driverDesc = subKey?.GetValue("DriverDesc") as string;
                                    break;
                                }
                            }
                        }
                    }
                }

                if (!string.IsNullOrEmpty(driverDesc))
                {
                    using (var enumKey = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Enum", false))
                    {
                        if (enumKey == null) return null;
                        foreach (var busName in enumKey.GetSubKeyNames())
                        {
                            using (var busKey = enumKey.OpenSubKey(busName, false))
                            {
                                if (busKey == null) continue;
                                foreach (var devName in busKey.GetSubKeyNames())
                                {
                                    using (var devKey = busKey.OpenSubKey(devName, false))
                                    {
                                        if (devKey == null) continue;
                                        var friendlyName = devKey.GetValue("FriendlyName") as string;
                                        var desc = devKey.GetValue("DeviceDesc") as string;
                                        if ((friendlyName != null && friendlyName.Contains(driverDesc)) ||
                                            (desc != null && desc.Contains(driverDesc)))
                                        {
                                            return $@"SYSTEM\CurrentControlSet\Enum\{busName}\{devName}";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Debug($"Find adapter enum path error: {ex.Message}");
            }
            return null;
        }

        public abstract Task ExecuteAsync();

        public override string ToString() => $"{Name}: {SpoofCount} spoofed, {ErrorCount} errors";
    }

    public interface ISpoofManager
    {
        IReadOnlyDictionary<string, string> OriginalValues { get; }
        void Clear();
        void AddOriginal(string key, string value);
        int RevertAll();
        string ExportBackup();
        Dictionary<string, string> ImportBackup(string json);
    }

    public class SpoofManager : ISpoofManager
    {
        private static readonly ConcurrentDictionary<string, string> _originalValues = new ConcurrentDictionary<string, string>();

        public static readonly ISpoofManager Instance = new SpoofManager();

        public IReadOnlyDictionary<string, string> OriginalValues => _originalValues;

        public void Clear() => _originalValues.Clear();

        public void AddOriginal(string key, string value)
        {
            _originalValues.TryAdd(key, value);
        }

        public int RevertAll()
        {
            int restored = 0;
            var snapshot = _originalValues.ToList();
            _originalValues.Clear();

            foreach (var kvp in snapshot)
            {
                try
                {
                    var parts = kvp.Key.Split('|');
                    if (parts.Length == 2)
                    {
                        using (var key = Registry.LocalMachine.OpenSubKey(parts[0], true))
                        {
                            if (key != null)
                            {
                                key.SetValue(parts[1], kvp.Value, RegistryValueKind.String);
                                restored++;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Debug($"Revert failed for {kvp.Key}: {ex.Message}");
                }
            }
            return restored;
        }

        public string ExportBackup()
        {
            try
            {
                var snapshot = new Dictionary<string, string>(_originalValues);
                return JsonSerializer.Serialize(snapshot, new JsonSerializerOptions
                {
                    WriteIndented = true
                });
            }
            catch (Exception ex)
            {
                Logger.Debug($"Backup export error: {ex.Message}");
                return null;
            }
        }

        public Dictionary<string, string> ImportBackup(string json)
        {
            try
            {
                return JsonSerializer.Deserialize<Dictionary<string, string>>(json);
            }
            catch (Exception ex)
            {
                Logger.Debug($"Backup import error: {ex.Message}");
                return null;
            }
        }
    }

    public static class RegistryHelper
    {
        public static bool TakeOwnershipAndWrite(string path, string name, string value)
        {
            try
            {
                using (var key = Registry.LocalMachine.OpenSubKey(path, true))
                {
                    if (key != null)
                    {
                        key.SetValue(name, value, RegistryValueKind.String);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Debug($"Registry write error: {ex.Message}");
            }

            try
            {
                string tempFile = Path.GetTempFileName();
                File.WriteAllText(tempFile, $"Windows Registry Editor Version 5.00\n\n[{path}]\n\"{name}\"=\"{value}\"");
                var psi = new ProcessStartInfo("reg.exe", $"import \"{tempFile}\"")
                {
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                using (var proc = Process.Start(psi))
                {
                    proc?.WaitForExit(5000);
                    bool success = proc != null && proc.ExitCode == 0;
                    try { File.Delete(tempFile); } catch { }
                    return success;
                }
            }
            catch (Exception ex)
            {
                Logger.Debug($"Reg.exe import error: {ex.Message}");
                return false;
            }
        }
    }
}
