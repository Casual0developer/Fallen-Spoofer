using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace FallenSpoofer.Spoofers
{

    public class BanTracesCleaner : SpoofModule
    {
        public override string Name => "Ban Traces (BETA)";
        public override string Description => "Safely remove game ban traces without breaking Windows";

        private int deletedCount = 0;

        private static readonly string[] SafeExtensions = { ".log", ".dmp", ".etl", ".cab", ".old", ".bak", ".tmp" };

        private static readonly string[] SafeTempDirs = {
            // Fortnite
            "FortniteGame\\Saved\\Logs",
            "FortniteGame\\Saved\\Crashes",
            "FortniteGame\\Saved\\Config",
            "FortniteGame\\Saved\\Logs\\FortniteGame",
            // VALORANT
            "Riot Games\\VALORANT\\Saved\\Logs",
            "Riot Games\\VALORANT\\Saved\\Crashes",
            "Riot Games\\VALORANT\\Saved\\Config",
            "Riot Games\\VALORANT\\Saved\\Logs\\ShooterGame",
            // Anti-Cheat
            "EasyAntiCheat",
            "BattlEye",
            // Call of Duty
            "Activision\\CoD\\logs",
            "Activision\\CoD\\crash",
            // Epic Games
            "EpicGamesLauncher\\Saved\\Logs",
            "EpicGamesLauncher\\Saved\\WebCache",
            // Steam
            "Steam\\logs",
            "Steam\\dumps",
            // EA / Origin
            "Electronic Arts\\EA Desktop\\Logs",
            "Origin\\Logs",
            // Ubisoft
            "Ubisoft Game Launcher\\logs",
            // Minecraft
            "Packages\\Microsoft.MinecraftUWP_8wekyb3d8bbwe\\LocalState\\logs",
            // Rockstar
            "Rockstar Games\\Launcher\\Logs",
            "Rockstar Games\\Social Club",
            // Discord (game overlay traces)
            "discord\\Cache",
            "discord\\Code Cache",
            // NVIDIA GeForce Experience
            "NVIDIA Corporation\\NVIDIA GeForce Experience\\Logs",
            // AMD Radeon
            "AMD\\CN",
        };

        private static readonly string[] SafeFileNames = {
            "stdout.txt", "stderr.txt", "debug.log",
            "boot.log", "game.log", "output_log.txt",
            "crash.log", "error.log", "player.log"
        };

        public override async Task ExecuteAsync()
        {
            Log("[*] Starting Ban Trace Removal (SAFE)...");
            Log("[*] WARNING: Only game/anti-cheat traces will be removed");

            deletedCount = 0;

            await SafeFlushDNSCacheAsync();
            await SafeClearGameLogsAsync();
            await SafeClearCrashDumpsOlderThanDaysAsync(3);
            await SafeClearRecentFilesAsync();
            await SafeClearEventLogsAsync();
            await SafeClearPrefetchAsync();
            await SafeClearWindowsTempTracesAsync();

            Log($"[+] Ban traces removed: {deletedCount} files cleaned");
        }

        private async Task SafeFlushDNSCacheAsync()
        {
            Log("[*] Flushing DNS cache...");
            try
            {
                bool result = await RunProcessAsync("ipconfig.exe", "/flushdns", CancellationToken);
                if (result) Log("[+] DNS cache flushed");
                else Log("[!] DNS flush returned non-zero exit", WarnColor);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Log($"[!] DNS flush failed: {ex.Message}", WarnColor);
            }
        }

        private async Task SafeClearGameLogsAsync()
        {
            Log("[*] Cleaning game/anti-cheat logs from %LOCALAPPDATA%...");

            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (string.IsNullOrEmpty(localAppData))
            {
                Log("[!] Cannot find LocalAppData path", ErrorColor);
                return;
            }

            foreach (var safeDir in SafeTempDirs)
            {
                CancellationToken.ThrowIfCancellationRequested();

                string fullPath = Path.Combine(localAppData, safeDir);
                if (!Directory.Exists(fullPath)) continue;

                try
                {
                    var files = Directory.GetFiles(fullPath, "*", SearchOption.AllDirectories);
                    foreach (var file in files)
                    {
                        CancellationToken.ThrowIfCancellationRequested();

                        try
                        {
                            string ext = Path.GetExtension(file).ToLowerInvariant();
                            string fileName = Path.GetFileName(file);

                            if (SafeExtensions.Contains(ext) || SafeFileNames.Any(f => fileName.StartsWith(f, StringComparison.OrdinalIgnoreCase)))
                            {
                                File.SetAttributes(file, FileAttributes.Normal);
                                File.Delete(file);
                                Interlocked.Increment(ref deletedCount);
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.Debug($"Delete error for {file}: {ex.Message}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log($"[!] Error cleaning {safeDir}: {ex.Message}", WarnColor);
                }
            }

            await Task.WhenAll(
                SafeCleanEACAsync(),
                SafeCleanBattlEyeAsync()
            );
        }

        private async Task SafeCleanEACAsync()
        {
            try
            {
                await Task.Run(() =>
                {
                    string eaServicePath = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                        "EasyAntiCheat");

                    if (!Directory.Exists(eaServicePath)) return;

                    var logFiles = Directory.GetFiles(eaServicePath, "*.log", SearchOption.AllDirectories);
                    foreach (var log in logFiles)
                    {
                        CancellationToken.ThrowIfCancellationRequested();
                        try
                        {
                            File.SetAttributes(log, FileAttributes.Normal);
                            File.Delete(log);
                            Interlocked.Increment(ref deletedCount);
                        }
                        catch (Exception ex)
                        {
                            Logger.Debug($"EAC delete error: {ex.Message}");
                        }
                    }
                }, CancellationToken);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Log($"[!] EAC cleanup error: {ex.Message}", WarnColor);
            }
        }

        private async Task SafeCleanBattlEyeAsync()
        {
            try
            {
                await Task.Run(() =>
                {
                    string bePath = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                        "Common Files", "BattlEye");

                    if (!Directory.Exists(bePath)) return;

                    var logFiles = Directory.GetFiles(bePath, "*.log", SearchOption.AllDirectories);
                    foreach (var log in logFiles)
                    {
                        CancellationToken.ThrowIfCancellationRequested();
                        try
                        {
                            File.SetAttributes(log, FileAttributes.Normal);
                            File.Delete(log);
                            Interlocked.Increment(ref deletedCount);
                        }
                        catch (Exception ex)
                        {
                            Logger.Debug($"BattlEye delete error: {ex.Message}");
                        }
                    }
                }, CancellationToken);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Log($"[!] BattlEye cleanup error: {ex.Message}", WarnColor);
            }
        }

        private async Task SafeClearCrashDumpsOlderThanDaysAsync(int days)
        {
            Log($"[*] Cleaning crash dumps older than {days} days...");

            await Task.WhenAll(
                CrashDumpsOlderThanDaysAsync(
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CrashDumps"),
                    "*.dmp", days),
                CrashDumpsOlderThanDaysAsync(@"C:\Windows\Minidump", "*.dmp", days)
            );
        }

        private async Task CrashDumpsOlderThanDaysAsync(string dirPath, string pattern, int days)
        {
            if (!Directory.Exists(dirPath)) return;

            try
            {
                await Task.Run(() =>
                {
                    var oldDumps = Directory.GetFiles(dirPath, pattern)
                        .Where(f =>
                        {
                            try { return File.GetLastWriteTime(f) < DateTime.Now.AddDays(-days); }
                            catch { return false; }
                        });

                    foreach (var file in oldDumps)
                    {
                        CancellationToken.ThrowIfCancellationRequested();
                        try
                        {
                            File.SetAttributes(file, FileAttributes.Normal);
                            File.Delete(file);
                            Interlocked.Increment(ref deletedCount);
                        }
                        catch (Exception ex)
                        {
                            Logger.Debug($"Crash dump delete error: {ex.Message}");
                        }
                    }
                }, CancellationToken);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Log($"[!] Crash dump cleanup error for {dirPath}: {ex.Message}", WarnColor);
            }
        }

        private async Task SafeClearRecentFilesAsync()
        {
            Log("[*] Cleaning recent files history...");

            string recentPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "Microsoft", "Windows", "Recent");

            if (Directory.Exists(recentPath))
            {
                await ClearFilesInDirectoryAsync(recentPath, "*.lnk");
            }

            string explorerPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Microsoft", "Windows", "Explorer");

            if (Directory.Exists(explorerPath))
            {
                await ClearFilesInDirectoryAsync(explorerPath, "thumbcache_*.db");
            }
        }

        private async Task SafeClearEventLogsAsync()
        {
            Log("[*] Clearing Windows Event Logs...");
            try
            {
                bool result = await RunProcessAsync("wevt.exe", "cl Application", CancellationToken);
                if (result) Log("[+] Application event log cleared");

                result = await RunProcessAsync("wevt.exe", "cl System", CancellationToken);
                if (result) Log("[+] System event log cleared");
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Log($"[!] Event log clear failed: {ex.Message}", WarnColor);
            }
        }

        private async Task SafeClearPrefetchAsync()
        {
            Log("[*] Clearing Prefetch cache...");
            try
            {
                string prefetchPath = @"C:\Windows\Prefetch";
                if (!Directory.Exists(prefetchPath)) return;

                await Task.Run(() =>
                {
                    var files = Directory.GetFiles(prefetchPath, "*.pf");
                    foreach (var file in files)
                    {
                        CancellationToken.ThrowIfCancellationRequested();
                        try
                        {
                            File.Delete(file);
                            Interlocked.Increment(ref deletedCount);
                        }
                        catch { }
                    }
                }, CancellationToken);
                Log("[+] Prefetch cache cleared");
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Log($"[!] Prefetch clear failed: {ex.Message}", WarnColor);
            }
        }

        private async Task SafeClearWindowsTempTracesAsync()
        {
            Log("[*] Cleaning Windows Temp traces...");
            try
            {
                string tempPath = Path.GetTempPath();
                if (!Directory.Exists(tempPath)) return;

                await Task.Run(() =>
                {
                    var files = Directory.GetFiles(tempPath, "*", SearchOption.TopDirectoryOnly);
                    foreach (var file in files)
                    {
                        CancellationToken.ThrowIfCancellationRequested();
                        try
                        {
                            string ext = Path.GetExtension(file).ToLowerInvariant();
                            if (SafeExtensions.Contains(ext))
                            {
                                File.SetAttributes(file, FileAttributes.Normal);
                                File.Delete(file);
                                Interlocked.Increment(ref deletedCount);
                            }
                        }
                        catch { }
                    }
                }, CancellationToken);
                Log("[+] Temp traces cleaned");
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Log($"[!] Temp traces cleanup error: {ex.Message}", WarnColor);
            }
        }

        private async Task ClearFilesInDirectoryAsync(string dirPath, string searchPattern)
        {
            try
            {
                await Task.Run(() =>
                {
                    var files = Directory.GetFiles(dirPath, searchPattern);
                    int deleted = 0;
                    foreach (var file in files)
                    {
                        CancellationToken.ThrowIfCancellationRequested();
                        try
                        {
                            File.Delete(file);
                            deleted++;
                        }
                        catch (Exception ex)
                        {
                            Logger.Debug($"File delete error: {ex.Message}");
                        }
                    }
                    if (deleted > 0)
                    {
                        Interlocked.Add(ref deletedCount, deleted);
                        Log($"[+] Cleared {deleted} files from {Path.GetFileName(dirPath)}");
                    }
                }, CancellationToken);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Log($"[!] Error clearing {dirPath}: {ex.Message}", WarnColor);
            }
        }
    }
}
