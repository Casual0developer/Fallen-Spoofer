using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FallenSpoofer.Spoofers
{
    public class UuidSpoof : SpoofModule
    {
        private const string CryptographyPath = @"SOFTWARE\Microsoft\Cryptography";
        private const string WindowsNtCurrentVersion = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion";
        private const string WindowsUpdatePath = @"SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate";
        private const string SqmClientPath = @"SOFTWARE\Microsoft\SQMClient";
        private const string SystemInformationPath = @"SYSTEM\CurrentControlSet\Control\SystemInformation";
        private const string TpmPath = @"SYSTEM\CurrentControlSet\Control\TPM";
        private const string BiosPath = @"HARDWARE\DESCRIPTION\System\BIOS";
        private const string NetbtPath = @"SYSTEM\CurrentControlSet\Services\NetBT\Parameters";
        private const string HardwareProfilesPath = @"SYSTEM\CurrentControlSet\Control\IDConfigDB\Hardware Profiles\0001";
        private const string NetworkClass = @"SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}";

        public override string Name => "UUID / GUID";
        public override string Description => "Spoof all unique identifiers including MachineGuid, BuildGUID, hardware IDs";

        public override Task ExecuteAsync()
        {
            Log("[*] Starting UUID/GUID spoofing...");

            if (!IsAdmin())
            {
                Log("[!] Admin required!", ErrorColor);
                return Task.CompletedTask;
            }

            int count = 0;
            int errors = 0;

            try
            {
                var uuids = new Dictionary<string, string>
                {
                    ["MachineGuid"] = Guid.NewGuid().ToString(),
                    ["BuildGUID"] = Guid.NewGuid().ToString(),
                    ["HardwareGuid"] = "{" + Guid.NewGuid().ToString() + "}",
                    ["ComputerId"] = "{" + Guid.NewGuid().ToString().ToUpper() + "}",
                    ["MachineId"] = "{" + Guid.NewGuid().ToString().ToUpper() + "}",
                    ["SusClientId"] = Guid.NewGuid().ToString(),
                    ["TpmId"] = Guid.NewGuid().ToString(),
                    ["NetbiosId"] = "NET" + RandomHex(5).ToUpper(),
                    ["ProfileGuid"] = "{" + Guid.NewGuid().ToString() + "}",
                    ["DeviceId"] = "{" + Guid.NewGuid().ToString().ToUpper() + "}"
                };

                WriteAndSave(CryptographyPath, "MachineGuid", uuids["MachineGuid"]);
                count++;

                WriteAndSave(WindowsNtCurrentVersion, "BuildGUID", uuids["BuildGUID"]);
                WriteAndSave(WindowsNtCurrentVersion, "BuildBranch", "rs_prerelease");
                count += 2;

                WriteAndSave(HardwareProfilesPath, "HwProfileGuid", uuids["HardwareGuid"]);
                WriteAndSave(HardwareProfilesPath, "Guid", uuids["ProfileGuid"]);
                count += 2;

                if (ValidateRegistryPath(SystemInformationPath) && RegistryExists(SystemInformationPath))
                {
                    WriteAndSave(SystemInformationPath, "ComputerHardwareId", uuids["ComputerId"]);
                    WriteAndSave(SystemInformationPath, "SystemSku", uuids["ComputerId"]);
                    WriteAndSave(SystemInformationPath, "SystemManufacturer", "ASUSTeK COMPUTER INC.");
                    WriteAndSave(SystemInformationPath, "SystemProductName", "System Product Name");
                    count += 4;
                }

                WriteIfExists(SqmClientPath, "MachineId", uuids["MachineId"]);
                count++;

                WriteAndSave(WindowsUpdatePath, "SusClientId", uuids["SusClientId"]);
                WriteAndSave(WindowsUpdatePath, "SusClientIDValidation", RandomHex(32));
                count += 2;

                if (ValidateRegistryPath(TpmPath) && RegistryExists(TpmPath))
                {
                    WriteAndSave(TpmPath, "TPMId", uuids["TpmId"]);
                    WriteAndSave(TpmPath, "ManufacturerId", "INTC");
                    WriteAndSave(TpmPath, "FirmwareVersion", $"{RandomHex(1)}.{RandomHex(1)}.{RandomHex(2)}.{RandomHex(1)}");
                    count += 3;
                }

                string productId = $"{RandomHex(5).ToUpper()}-{RandomHex(5).ToUpper()}-{RandomHex(5).ToUpper()}-{RandomHex(5).ToUpper()}-{RandomHex(5).ToUpper()}";
                WriteAndSave(WindowsNtCurrentVersion, "ProductId", productId);
                count++;

                WriteIfExists(WindowsNtCurrentVersion, "DigitalProductId", RandomHex(52));
                WriteIfExists(WindowsNtCurrentVersion, "DigitalProductId4", RandomHex(64));
                count += 2;

                WriteAndSave(WindowsNtCurrentVersion, "InstallDate",
                    ((int)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds).ToString());
                WriteAndSave(WindowsNtCurrentVersion, "InstallTime",
                    ((long)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds).ToString());
                count += 2;

                if (ValidateRegistryPath(BiosPath) && RegistryExists(BiosPath))
                {
                    WriteAndSave(BiosPath, "SystemSku", uuids["HardwareGuid"]);
                    WriteAndSave(BiosPath, "SystemSerialNumber", RandomHex(12).ToUpper());
                    count += 2;
                }

                if (ValidateRegistryPath(NetbtPath) && RegistryExists(NetbtPath))
                {
                    WriteAndSave(NetbtPath, "NameServer", uuids["NetbiosId"]);
                    WriteAndSave(NetbtPath, "DomainName", uuids["NetbiosId"]);
                    count += 2;
                }

                for (int i = 0; i < 16; i++)
                {
                    CancellationToken.ThrowIfCancellationRequested();

                    try
                    {
                        string netPath = $@"{NetworkClass}\{i:D4}";
                        if (!ValidateRegistryPath(netPath) || !RegistryExists(netPath))
                            continue;

                        WriteAndSave(netPath, "NetworkAdapterCMAa", Guid.NewGuid().ToString());
                        count++;
                    }
                    catch (Exception ex)
                    {
                        errors++;
                        Logger.Debug($"Network adapter {i} error: {ex.Message}");
                    }
                }

                if (count == 0)
                    Log("[~] No UUID paths found", WarnColor);
                else
                    Log($"[+] UUID/GUID spoofed ({count} entries, {errors} errors)");
            }
            catch (Exception ex)
            {
                Log($"[!] UUID spoof failed: {ex.Message}", ErrorColor);
                Logger.Debug(ex.ToString());
            }

            return Task.CompletedTask;
        }
    }
}
