using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FallenSpoofer.Spoofers
{
    public class RevertModule
    {
        private readonly IProgress<LogEntry> progress;
        private readonly Color successColor;
        private readonly Color errorColor;
        private readonly Color warnColor;
        private readonly string backupFile;
        private readonly Func<string, Task> restartAdapterAsync;
        private int restoredCount;

        public RevertModule(
            IProgress<LogEntry> progress,
            Color successColor,
            Color errorColor,
            Color warnColor,
            string backupFile,
            Func<string, Task> restartAdapterAsync = null)
        {
            this.progress = progress;
            this.successColor = successColor;
            this.errorColor = errorColor;
            this.warnColor = warnColor;
            this.backupFile = backupFile;
            this.restartAdapterAsync = restartAdapterAsync;
            this.restoredCount = 0;
        }

        public async Task<RevertResult> ExecuteAsync(CancellationToken ct = default)
        {
            Log("[*] Starting revert operation...");

            if (!ValidateBackupFile())
            {
                Log("[~] No backup file found - nothing to revert", warnColor);
                return new RevertResult { Status = RevertStatus.NoBackup };
            }

            var entries = LoadBackupEntries();
            if (entries == null || entries.Count == 0)
            {
                Log("[!] Backup file is empty or invalid", warnColor);
                return new RevertResult { Status = RevertStatus.Empty };
            }

            Log($"[*] Loaded {entries.Count} entries from backup");

            var macEntries = new Dictionary<string, string>();
            int restored = 0;
            int failed = 0;

            foreach (var kvp in entries)
            {
                ct.ThrowIfCancellationRequested();

                try
                {
                    if (kvp.Key.StartsWith("MAC_"))
                    {
                        string guid = kvp.Key.Substring(4);
                        if (ValidateGuid(guid) && !string.IsNullOrEmpty(kvp.Value))
                        {
                            macEntries[kvp.Key] = kvp.Value;
                        }
                        else
                        {
                            Log($"[!] Invalid MAC entry: {kvp.Key}", warnColor);
                            failed++;
                        }
                        continue;
                    }

                    if (RestoreRegistryValue(kvp.Key, kvp.Value))
                    {
                        restored++;
                    }
                    else
                    {
                        failed++;
                    }
                }
                catch (Exception ex)
                {
                    Log($"[!] Revert error for {kvp.Key}: {ex.Message}", errorColor);
                    Logger.Debug(ex.ToString());
                    failed++;
                }
            }

                if (macEntries.Count > 0)
                {
                    ct.ThrowIfCancellationRequested();
                    Log($"[*] Restoring {macEntries.Count} MAC address(es)...", warnColor);
                    var macRevert = new MacRevertModule(progress, successColor, errorColor, warnColor);
                    bool macOk = await macRevert.RevertMacAddresses(macEntries, ct);
                    if (macOk) restored += macEntries.Count;
                    else failed += macEntries.Count;
                }

            bool allSuccess = failed == 0;

            if (allSuccess)
            {
                try
                {
                    if (File.Exists(backupFile))
                        File.Delete(backupFile);
                }
                catch (Exception ex)
                {
                    Log($"[!] Could not delete backup file: {ex.Message}", warnColor);
                    Logger.Debug(ex.ToString());
                }
            }
            else
            {
                Log("[!] Backup preserved due to partial failure - can retry revert", warnColor);
            }

            SpoofManager.Instance.Clear();

            Color status = failed > 0 ? warnColor : successColor;
            Log($"[+] Reverted {restored} values" + (failed > 0 ? $", {failed} failed" : ""), status);
            restoredCount = restored;

            return new RevertResult
            {
                Status = failed > 0 ? RevertStatus.PartialSuccess : RevertStatus.Success,
                RestoredCount = restored,
                FailedCount = failed
            };
        }

        private bool ValidateBackupFile()
        {
            if (string.IsNullOrWhiteSpace(backupFile)) return false;
            return File.Exists(backupFile);
        }

        private Dictionary<string, string> LoadBackupEntries()
        {
            try
            {
                string json = File.ReadAllText(backupFile);
                if (string.IsNullOrWhiteSpace(json)) return null;

                return SpoofManager.Instance.ImportBackup(json);
            }
            catch (Exception ex)
            {
                Log($"[!] Failed to load backup: {ex.Message}", errorColor);
                Logger.Debug(ex.ToString());
                return null;
            }
        }

        private bool RestoreRegistryValue(string key, string value)
        {
            var parts = key.Split('|');
            if (parts.Length != 2)
            {
                Log($"[!] Invalid backup key format: {key}", warnColor);
                return false;
            }

            try
            {
                using (var openedKey = Registry.LocalMachine.OpenSubKey(parts[0], true))
                {
                    if (openedKey != null)
                    {
                        openedKey.SetValue(parts[1], value, RegistryValueKind.String);
                        return true;
                    }
                    else
                    {
                        Log($"[!] Original key not found (skipping): {key}", warnColor);
                        return false;
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                Log($"[!] Access denied restoring: {key}", errorColor);
            }
            catch (Exception ex)
            {
                Log($"[!] Registry restore error {key}: {ex.Message}", errorColor);
                Logger.Debug(ex.ToString());
            }
            return false;
        }

        private bool ValidateGuid(string guid)
        {
            if (string.IsNullOrWhiteSpace(guid)) return false;
            return Guid.TryParse(guid.Trim('{', '}'), out _);
        }

        private void Log(string message, Color? color = null)
        {
            try
            {
                progress?.Report(new LogEntry(message, color ?? Color.Gray));
            }
            catch (Exception ex)
            {
                Logger.Debug($"Log error: {ex.Message}");
            }
        }
    }

    public enum RevertStatus
    {
        Success,
        PartialSuccess,
        NoBackup,
        Empty
    }

    public class RevertResult
    {
        public RevertStatus Status { get; set; }
        public int RestoredCount { get; set; }
        public int FailedCount { get; set; }
        public bool HasBackup => Status == RevertStatus.Success || Status == RevertStatus.PartialSuccess;
    }
}

