using System;
using System.Drawing;
using System.Windows.Forms;

namespace FallenSpoofer.Modules
{
    public class TitleBar : Panel
    {
        private Color bgCard;
        private Color accentColor;
        private Color textPrimary;
        private Color warnColor;
        private Color errorColor;

        private bool dragging = false;
        private Point dragStart;

        public event EventHandler DoubleClickToggleFullscreen;

        public TitleBar(Color cardColor, Color accent, Color text, Color warn, Color error)
        {
            this.bgCard = cardColor;
            this.accentColor = accent;
            this.textPrimary = text;
            this.warnColor = warn;
            this.errorColor = error;

            this.Dock = DockStyle.Top;
            this.Height = 36;
            this.BackColor = bgCard;

            this.MouseDown += TitleBar_MouseDown;
            this.MouseUp += TitleBar_MouseUp;
            this.MouseMove += TitleBar_MouseMove;
            this.MouseDoubleClick += (s, e) => DoubleClickToggleFullscreen?.Invoke(this, EventArgs.Empty);
        }

        public void BuildControls(string title, Action onClose, Action onMinimize, Action onFullscreen)
        {
            this.Controls.Clear();

            var titleLabel = new Label
            {
                Text = $"  {title}",
                ForeColor = textPrimary,
                Font = new Font("Segoe UI Variable", 10F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(12, 9)
            };

            var buttonPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Right,
                FlowDirection = FlowDirection.RightToLeft,
                AutoSize = true,
                Height = 36,
                BackColor = bgCard,
                Padding = new Padding(0),
                Margin = new Padding(0)
            };

            var closeBtn = CreateTitleButton("X", new Size(30, 30), bgCard, errorColor, 10F);
            closeBtn.FlatAppearance.MouseOverBackColor = Color.White;
            closeBtn.Click += (s, e) => onClose?.Invoke();

            var fullscreenBtn = CreateTitleButton("[ ]", new Size(30, 30), bgCard, accentColor, 7.5F);
            fullscreenBtn.Click += (s, e) => onFullscreen?.Invoke();

            var minBtn = CreateTitleButton("-", new Size(30, 30), bgCard, warnColor, 9F);
            minBtn.Click += (s, e) => onMinimize?.Invoke();

            buttonPanel.Controls.AddRange(new Control[] { closeBtn, fullscreenBtn, minBtn });
            this.Controls.AddRange(new Control[] { titleLabel, buttonPanel });
        }

        private Button CreateTitleButton(string text, Size size, Color back, Color fore, float fontSize)
        {
            return new Button
            {
                Text = text,
                FlatStyle = FlatStyle.Flat,
                BackColor = back,
                ForeColor = fore,
                Size = size,
                Font = new Font("Segoe UI Variable", fontSize),
                Cursor = Cursors.Hand,
                Margin = new Padding(1, 5, 0, 0),
                FlatAppearance = { BorderSize = 0, MouseOverBackColor = Color.FromArgb(49, 50, 68) }
            };
        }

        private void TitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dragging = true;
                dragStart = e.Location;
            }
        }

        private void TitleBar_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void TitleBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Parent.Left += e.X - dragStart.X;
                Parent.Top += e.Y - dragStart.Y;
            }
        }
    }
}
