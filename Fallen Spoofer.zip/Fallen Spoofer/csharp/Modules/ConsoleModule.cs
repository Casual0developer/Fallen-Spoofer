using System;
using System.Drawing;
using System.Windows.Forms;
using FallenSpoofer.Spoofers;

namespace FallenSpoofer.Modules
{
    public class ConsoleModule : Form
    {
        private RichTextBox logBox;
        public RichTextBox LogBoxRef => logBox;
        private Panel titleBar;
        private bool dragging = false;
        private Point dragStart;

        private bool isFullscreen = false;
        private Size previousSize;
        private Point previousLocation;

        private IProgress<LogEntry> logProgress;
        private readonly Progress<LogEntry> internalProgress;

        public ConsoleModule()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - 540, 50);
            this.Size = new Size(520, 680);
            this.BackColor = Color.FromArgb(32, 32, 32);
            this.DoubleBuffered = true;
            this.ShowInTaskbar = false;
            this.MinimumSize = new Size(350, 250);
            this.Font = new Font("Segoe UI Variable", 9F);

            internalProgress = new Progress<LogEntry>(entry =>
            {
                try
                {
                    AppendLogInternal(entry.Message, entry.Color);
                }
                catch (Exception ex)
                {
                    Logger.Debug($"Internal progress log error: {ex.Message}");
                }
            });

            logProgress = internalProgress;

            BuildGUI();
        }

        public IProgress<LogEntry> GetProgress() => logProgress;

        public void AppendLog(string text, Color color)
        {
            logProgress?.Report(new LogEntry(text, color));
        }

        private void BuildGUI()
        {
            titleBar = new Panel { Dock = DockStyle.Top, Height = 34, BackColor = Color.FromArgb(45, 45, 45) };
            titleBar.MouseDown += (s, e) => { if (e.Button == MouseButtons.Left) { dragging = true; dragStart = e.Location; } };
            titleBar.MouseUp += (s, e) => dragging = false;
            titleBar.MouseMove += (s, e) =>
            {
                if (dragging)
                {
                    this.Left += e.X - dragStart.X;
                    this.Top += e.Y - dragStart.Y;
                }
            };
            titleBar.MouseDoubleClick += (s, e) => ToggleFullscreen();

            var titleLabel = new Label
            {
                Text = "  Console",
                ForeColor = Color.FromArgb(96, 165, 250),
                Font = new Font("Segoe UI Variable", 10F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(10, 8)
            };

            var buttonPanel = new Panel
            {
                Dock = DockStyle.Right,
                Height = 34,
                BackColor = Color.FromArgb(45, 45, 45)
            };

            var buttonFont = new Font("Segoe UI Variable", 8.5F);
            var pad = 10;

            var clearBtn = new Button
            {
                Text = "Clear",
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(45, 45, 45),
                ForeColor = Color.FromArgb(180, 180, 180),
                Font = buttonFont,
                Height = 28,
                FlatAppearance = { BorderSize = 0, MouseOverBackColor = Color.FromArgb(70, 70, 70) }
            };
            var clearWidth = TextRenderer.MeasureText(clearBtn.Text, buttonFont).Width + pad;
            clearBtn.Width = clearWidth;
            clearBtn.Click += (s, e) => ClearLog();

            var copyBtn = new Button
            {
                Text = "Copy All",
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(45, 45, 45),
                ForeColor = Color.FromArgb(180, 180, 180),
                Font = buttonFont,
                Height = 28,
                FlatAppearance = { BorderSize = 0, MouseOverBackColor = Color.FromArgb(70, 70, 70) }
            };
            var copyWidth = TextRenderer.MeasureText(copyBtn.Text, buttonFont).Width + pad;
            copyBtn.Width = copyWidth;
            copyBtn.Click += (s, e) =>
            {
                try
                {
                    string text = logBox.Text;
                    if (!string.IsNullOrEmpty(text))
                    {
                        this.Invoke(new Action(() =>
                        {
                            try { Clipboard.SetText(text); } catch { }
                        }));
                        titleLabel.Text = "  Copied!";
                        var timer = new System.Windows.Forms.Timer { Interval = 1500 };
                        timer.Tick += (s2, e2) => { timer.Stop(); timer.Dispose(); titleLabel.Text = "  Console"; };
                        timer.Start();
                    }
                }
                catch (Exception ex)
                {
                    Logger.Debug($"Clipboard error: {ex.Message}");
                }
            };

            var closeBtn = new Button
            {
                Text = "X",
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(45, 45, 45),
                ForeColor = Color.FromArgb(244, 67, 54),
                Font = new Font("Segoe UI Variable", 10F, FontStyle.Bold),
                Width = 30,
                Height = 30,
                FlatAppearance = { BorderSize = 0, MouseOverBackColor = Color.White, MouseDownBackColor = Color.FromArgb(220, 220, 220) }
            };
            closeBtn.Click += (s, e) => this.Hide();

            var totalWidth = clearWidth + copyWidth + closeBtn.Width + 14;
            buttonPanel.Width = totalWidth;

            closeBtn.Location = new Point(totalWidth - closeBtn.Width - 3, 2);
            copyBtn.Location = new Point(clearWidth + 5, 2);
            clearBtn.Location = new Point(3, 2);

            buttonPanel.Controls.AddRange(new Control[] { closeBtn, copyBtn, clearBtn });
            titleBar.Controls.AddRange(new Control[] { titleLabel, buttonPanel });

            logBox = new RichTextBox
            {
                ReadOnly = true,
                BackColor = Color.FromArgb(25, 25, 25),
                ForeColor = Color.FromArgb(200, 200, 200),
                Font = new Font("Cascadia Code", 9F),
                BorderStyle = BorderStyle.None,
                Dock = DockStyle.Fill,
                ScrollBars = RichTextBoxScrollBars.Vertical,
                DetectUrls = false,
                WordWrap = false
            };

            this.Paint += (s, e) =>
            {
                using (var pen = new Pen(Color.FromArgb(70, 70, 70), 1))
                    e.Graphics.DrawRectangle(pen, 0, 0, this.Width - 1, this.Height - 1);
            };

            this.Controls.AddRange(new Control[] { logBox, titleBar });
        }

        private void ToggleFullscreen()
        {
            if (isFullscreen)
            {
                this.Size = previousSize;
                this.Location = previousLocation;
                this.WindowState = FormWindowState.Normal;
                isFullscreen = false;
            }
            else
            {
                previousSize = this.Size;
                previousLocation = this.Location;
                this.WindowState = FormWindowState.Normal;
                this.Bounds = Screen.PrimaryScreen.WorkingArea;
                isFullscreen = true;
            }
        }

        private void ClearLog()
        {
            try
            {
                if (!logBox.IsHandleCreated) return;
                logBox.SuspendLayout();
                logBox.Visible = false;
                logBox.Clear();
                logBox.Visible = true;
                logBox.ResumeLayout();
                logBox.Refresh();
            }
            catch (Exception ex)
            {
                Logger.Debug($"ClearLog error: {ex.Message}");
            }
        }

        private void AppendLogInternal(string text, Color color)
        {
            try
            {
                if (logBox == null || !logBox.IsHandleCreated) return;

                if (logBox.TextLength > 50000)
                {
                    logBox.Select(0, logBox.TextLength / 2);
                    logBox.SelectedText = "";
                    logBox.Select(logBox.TextLength, 0);
                }

                logBox.SuspendLayout();
                int start = logBox.TextLength;
                logBox.AppendText(text + "\n");
                logBox.Select(start, logBox.TextLength - start);
                logBox.SelectionColor = color;
                logBox.Select(logBox.TextLength, 0);
                logBox.ScrollToCaret();
                logBox.ResumeLayout();
            }
            catch (Exception ex)
            {
                Logger.Debug($"AppendLog error: {ex.Message}");
            }
        }
    }
}
