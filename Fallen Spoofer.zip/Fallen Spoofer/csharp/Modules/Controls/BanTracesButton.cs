using System;
using System.Drawing;
using System.Windows.Forms;

namespace FallenSpoofer.Modules.Controls
{
    public class BanTracesButton : Button
    {
        private Color normalColor = Color.FromArgb(60, 35, 35);
        private Color hoverColor = Color.FromArgb(80, 45, 45);

        public BanTracesButton()
        {
            this.Text = "Remove Ban Traces (BETA)";
            this.FlatStyle = FlatStyle.Flat;
            this.BackColor = normalColor;
            this.ForeColor = Color.White;
            this.Font = new Font("Segoe UI Variable", 9F, FontStyle.Regular);
            this.Cursor = Cursors.Hand;
            this.MinimumSize = new Size(80, 36);
            this.Margin = new Padding(5);
            this.Padding = new Padding(0, 2, 0, 2);
            this.FlatAppearance.BorderSize = 0;
            this.FlatAppearance.MouseOverBackColor = hoverColor;
            this.FlatAppearance.MouseDownBackColor = Color.FromArgb(50, 30, 30);
        }
    }
}
