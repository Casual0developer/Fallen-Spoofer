using System;
using System.Drawing;
using System.Windows.Forms;

namespace FallenSpoofer.Modules.Controls
{
    public class RevertButton : Button
    {
        private Color normalColor = Color.FromArgb(60, 100, 180);
        private Color hoverColor = Color.FromArgb(70, 110, 200);

        public RevertButton()
        {
            this.Text = "REVERT";
            this.FlatStyle = FlatStyle.Flat;
            this.BackColor = normalColor;
            this.ForeColor = Color.White;
            this.Font = new Font("Segoe UI Variable", 10F, FontStyle.Bold);
            this.Cursor = Cursors.Hand;
            this.MinimumSize = new Size(80, 48);
            this.Margin = new Padding(5);
            this.Padding = new Padding(0, 2, 0, 2);
            this.FlatAppearance.BorderSize = 0;
            this.FlatAppearance.MouseOverBackColor = hoverColor;
            this.FlatAppearance.MouseDownBackColor = Color.FromArgb(50, 90, 160);
        }

        public void SetSpoofing(bool spoofing)
        {
            this.Enabled = !spoofing;
        }
    }
}
