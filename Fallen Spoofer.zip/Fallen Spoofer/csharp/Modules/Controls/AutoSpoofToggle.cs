using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace FallenSpoofer.Modules.Controls
{
    public class AutoSpoofToggle : Control
    {
        private bool _checked = false;
        private float _animProgress = 0f;
        private System.Windows.Forms.Timer _animTimer;
        private bool _suppressEvent = false;
        public event Action<bool> CheckedChanged;

        public bool Checked
        {
            get => _checked;
            set
            {
                _checked = value;
                StartAnim();
                Invalidate();
                if (!_suppressEvent)
                    CheckedChanged?.Invoke(_checked);
            }
        }

        public void SetChecked(bool value)
        {
            _suppressEvent = true;
            Checked = value;
            _suppressEvent = false;
        }

        public AutoSpoofToggle()
        {
            SetStyle(ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);
            Size = new Size(50, 26);
            Cursor = Cursors.Hand;
            BackColor = Color.Transparent;

            _animTimer = new System.Windows.Forms.Timer { Interval = 16 };
            _animTimer.Tick += (s, e) =>
            {
                if (_checked) _animProgress = Math.Min(_animProgress + 0.15f, 1f);
                else _animProgress = Math.Max(_animProgress - 0.15f, 0f);
                if (_animProgress <= 0f || _animProgress >= 1f) _animTimer.Stop();
                Invalidate();
            };
            Click += (s, e) => Checked = !_checked;
        }

        private void StartAnim() { _animTimer.Stop(); _animTimer.Start(); }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Color trackColor = Color.FromArgb(
                (int)(69 + (166 - 69) * _animProgress),
                (int)(71 + (227 - 71) * _animProgress),
                (int)(90 + (161 - 90) * _animProgress));
            using (var path = GetRoundedRect(ClientRectangle, Height / 2))
            using (var brush = new SolidBrush(trackColor))
                e.Graphics.FillPath(brush, path);

            int thumbSize = Height - 8;
            int thumbX = (int)(4 + (Width - thumbSize - 8) * _animProgress);
            int thumbY = 4;
            e.Graphics.FillEllipse(new SolidBrush(Color.FromArgb(60, 0, 0, 0)), thumbX + 1, thumbY + 2, thumbSize, thumbSize);
            e.Graphics.FillEllipse(new SolidBrush(Color.White), thumbX, thumbY, thumbSize, thumbSize);
        }

        private GraphicsPath GetRoundedRect(Rectangle rect, int radius)
        {
            var path = new GraphicsPath();
            path.AddArc(rect.X, rect.Y, radius * 2, radius * 2, 180, 90);
            path.AddArc(rect.Right - radius * 2, rect.Y, radius * 2, radius * 2, 270, 90);
            path.AddArc(rect.Right - radius * 2, rect.Bottom - radius * 2, radius * 2, radius * 2, 0, 90);
            path.AddArc(rect.X, rect.Bottom - radius * 2, radius * 2, radius * 2, 90, 90);
            path.CloseFigure();
            return path;
        }
    }
}
