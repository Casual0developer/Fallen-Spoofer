using System;
using System.Drawing;
using System.Windows.Forms;

namespace FallenSpoofer.Modules.Controls
{
    public class SpoofAllButton : Button
    {
        private Color normalColor = Color.FromArgb(180, 60, 60);
        private Color hoverColor = Color.FromArgb(200, 70, 70);

        public SpoofAllButton()
        {
            this.Text = "SPOOF ALL";
            this.FlatStyle = FlatStyle.Flat;
            this.BackColor = normalColor;
            this.ForeColor = Color.White;
            this.Font = new Font("Segoe UI Variable", 10F, FontStyle.Bold);
            this.Cursor = Cursors.Hand;
            this.MinimumSize = new Size(80, 48);
            this.Margin = new Padding(5);
            this.Padding = new Padding(0, 2, 0, 2);
            this.FlatAppearance.BorderSize = 0;
            this.FlatAppearance.MouseOverBackColor = hoverColor;
            this.FlatAppearance.MouseDownBackColor = Color.FromArgb(160, 50, 50);
        }

        public void SetSpoofing(bool spoofing)
        {
            this.Enabled = !spoofing;
            this.Text = spoofing ? "SPOOFING..." : "SPOOF ALL";
        }
    }
}
