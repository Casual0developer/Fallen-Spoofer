using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using FallenSpoofer.Spoofers;
using FallenSpoofer.Modules;
using FallenSpoofer.Modules.Controls;

namespace FallenSpoofer
{
    public class MainForm : Form
    {
        private Color bgDark = Color.FromArgb(32, 32, 32);
        private Color bgCard = Color.FromArgb(45, 45, 45);
        private Color accentColor = Color.FromArgb(96, 165, 250);
        private Color textPrimary = Color.FromArgb(255, 255, 255);
        private Color textSecondary = Color.FromArgb(170, 170, 170);
        private Color successColor = Color.FromArgb(76, 175, 80);
        private Color errorColor = Color.FromArgb(244, 67, 54);
        private Color warnColor = Color.FromArgb(255, 152, 0);
        private Color borderColor = Color.FromArgb(70, 70, 70);

        private TitleBar titleBar;
        private SpoofAllButton spoofButton;
        private RevertButton revertButton;
        private BanTracesButton banTracesBtn;
        private AutoSpoofToggle autoSpoofToggle;
        private bool autoSpoof = false;
        private ConsoleModule console;
        private SpoofModule[] modules;

        private static string appDataFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FallenSpoofer");
        private static string backupFile = Path.Combine(appDataFolder, "backup.json");
        private static string logFolder = Path.Combine(appDataFolder, "logs");
        private static string configFile = Path.Combine(appDataFolder, "config.json");

        private static readonly TimeSpan OperationTimeout = TimeSpan.FromMinutes(5);

        private StreamWriter logWriter;
        private string currentLogFile;
        private CancellationTokenSource operationCts;
        private bool isSpoofing = false;

        private IProgress<LogEntry> logProgress;
        private Label progressLabel;

        private bool isMainFullscreen = false;
        private Size previousMainSize;
        private Point previousMainLocation;

        public MainForm()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(520, 420);
            this.BackColor = bgDark;
            this.DoubleBuffered = true;
            this.Font = new Font("Segoe UI Variable", 9F);

            logProgress = new Progress<LogEntry>(entry =>
            {
                try
                {
                    console?.AppendLog(entry.Message, entry.Color);
                }
                catch (Exception ex)
                {
                    Logger.Debug($"Progress log error: {ex.Message}");
                }
            });

            modules = new SpoofModule[]
            {
                new MacSpoof(),
                new UuidSpoof(),
                new CpuSpoof(),
                new MainboardSpoof(),
                new DiskSpoof(),
                new GPUSpoof(),
                new NetworkSpoof(),
                new VbsSpoof(),
                new USBSpoof(),
                new MemorySpoof()
            };

            BuildGUI();

            try
            {
                string exePath = Application.ExecutablePath;
                this.Icon = Icon.ExtractAssociatedIcon(exePath) ?? SystemIcons.Application;
            }
            catch (Exception ex)
            {
                Logger.Debug($"Icon load error: {ex.Message}");
                this.Icon = SystemIcons.Application;
            }

            this.Paint += (s, e) =>
            {
                using (var pen = new Pen(borderColor, 1))
                    e.Graphics.DrawRectangle(pen, 0, 0, this.Width - 1, this.Height - 1);
            };

            console = new ConsoleModule();
            LoadConfig();

            SafeLog($"[+] Fallen Spoofer v{AutoUpdateChecker.CurrentVersion} ready");
            if (IsAdmin()) SafeLog("[+] Running as Administrator", successColor);
            else SafeLog("[!] NOT running as Administrator!", warnColor);

            _ = AutoUpdateChecker.ShowUpdateNotificationAsync(logProgress, accentColor, successColor);

            this.Shown += (s, e) =>
            {
                try
                {
                    var pending = AutoUpdateChecker.GetPendingMessages();
                    if (pending.Count > 0)
                    {
                        console.Show(this);
                        foreach (var msg in pending)
                        {
                            console.AppendLog(msg.Message, msg.Color);
                        }
                    }

                    if (autoSpoof && IsAdmin())
                    {
                        Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            await DoSpoofAsync();
                        });
                    }
                }
                catch (Exception ex)
                {
                    Logger.Debug($"Shown handler error: {ex.Message}");
                }
            };

            this.FormClosing += (s, e) =>
            {
                SaveConfig();
                CloseLogFile();
                ClickSoundPlayer.Cleanup();
            };

            CreateStartMenuShortcutOnce();
        }

        private void BuildGUI()
        {
            this.MinimumSize = new Size(400, 350);

            titleBar = new TitleBar(bgCard, accentColor, textPrimary, warnColor, errorColor);
            titleBar.BuildControls(
                $"Fallen Spoofer v{AutoUpdateChecker.CurrentVersion}",
                onClose: () => Application.Exit(),
                onMinimize: () => this.WindowState = FormWindowState.Minimized,
                onFullscreen: () => ToggleMainFullscreen()
            );

            var mainPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = bgDark,
                Padding = new Padding(16),
                RowCount = 5,
                ColumnCount = 2,
                AutoSize = true
            };

            mainPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            mainPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 56F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 48F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 44F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));

            spoofButton = new SpoofAllButton();
            spoofButton.Dock = DockStyle.Fill;
            spoofButton.Click += async (s, e) => { ClickSoundPlayer.Play(); await DoSpoofAsync(); };
            mainPanel.Controls.Add(spoofButton, 0, 0);

            revertButton = new RevertButton();
            revertButton.Dock = DockStyle.Fill;
            revertButton.Click += async (s, e) => { ClickSoundPlayer.Play(); await DoRevertAsync(); };
            mainPanel.Controls.Add(revertButton, 1, 0);

            var togglePanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.RightToLeft,
                BackColor = bgDark,
                Margin = new Padding(0)
            };
            var toggleLabel = new Label { Text = "Auto Spoof", ForeColor = textPrimary, Font = new Font("Segoe UI Variable", 10F), AutoSize = true, Anchor = AnchorStyles.Right | AnchorStyles.Top };
            toggleLabel.Location = new Point(0, 6);
            autoSpoofToggle = new AutoSpoofToggle { Checked = autoSpoof, Anchor = AnchorStyles.Right | AnchorStyles.Top };
            autoSpoofToggle.CheckedChanged += (val) =>
            {
                if (AutoUpdateChecker.HasUpdateAvailable)
                {
                    SafeLog($"[!] Please update to v{AutoUpdateChecker.LatestVersionString} before changing this setting!", warnColor);
                    autoSpoofToggle.SetChecked(autoSpoof);
                    return;
                }
                ClickSoundPlayer.Play();
                autoSpoof = val;
                SaveConfig();
                SafeLog($"[*] Auto-spoof {(val ? "enabled" : "disabled")}", accentColor);
            };
            togglePanel.Controls.AddRange(new Control[] { autoSpoofToggle, toggleLabel });
            mainPanel.Controls.Add(togglePanel, 1, 1);
            mainPanel.SetColumnSpan(togglePanel, 1);

            var spacer = new Panel { Dock = DockStyle.Fill, BackColor = bgDark };
            mainPanel.Controls.Add(spacer, 0, 2);
            mainPanel.SetColumnSpan(spacer, 2);

            banTracesBtn = new BanTracesButton();
            banTracesBtn.Dock = DockStyle.Fill;
            banTracesBtn.Click += async (s, e) => { ClickSoundPlayer.Play(); await DoRemoveBanTracesAsync(); };
            mainPanel.Controls.Add(banTracesBtn, 0, 3);
            mainPanel.SetColumnSpan(banTracesBtn, 2);

            progressLabel = new Label { Text = "", ForeColor = textSecondary, Font = new Font("Segoe UI Variable", 8F), Visible = false, Dock = DockStyle.Fill };
            mainPanel.Controls.Add(progressLabel, 0, 4);
            mainPanel.SetColumnSpan(progressLabel, 2);

            this.Controls.AddRange(new Control[] { mainPanel, titleBar });
        }

        private void ToggleMainFullscreen()
        {
            if (isMainFullscreen)
            {
                this.Bounds = Rectangle.Empty;
                this.Size = previousMainSize;
                this.Location = previousMainLocation;
                this.WindowState = FormWindowState.Normal;
                isMainFullscreen = false;
            }
            else
            {
                previousMainSize = this.Size;
                previousMainLocation = this.Location;
                this.WindowState = FormWindowState.Normal;
                this.Bounds = Screen.PrimaryScreen.WorkingArea;
                isMainFullscreen = true;
            }
        }

        private bool IsUpdateBlocking()
        {
            if (AutoUpdateChecker.HasUpdateAvailable)
            {
                SafeLog($"[!] Please update to v{AutoUpdateChecker.LatestVersionString} before using this feature!", warnColor);
                SafeLog($"[*] Download: https://github.com/Casual0developer/Fallen-Spoofer", warnColor);
                return true;
            }
            return false;
        }

        #region Logging

        private void SafeLog(string message, Color? col = null)
        {
            LogEntry entry = new LogEntry(message, col ?? textSecondary);
            logProgress?.Report(entry);

            try
            {
                lock (logWriter)
                {
                    logWriter?.WriteLine($"[{DateTime.Now:HH:mm:ss}] {message}");
                    logWriter?.Flush();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Log file write error: {ex.Message}");
            }
        }

        private void StartLogFile()
        {
            try
            {
                Directory.CreateDirectory(logFolder);
                currentLogFile = Path.Combine(logFolder, $"spoof_{DateTime.Now:yyyyMMdd_HHmmss}.txt");
                logWriter = new StreamWriter(currentLogFile, false, System.Text.Encoding.UTF8);
                logWriter.WriteLine($"=== Fallen Spoofer v{AutoUpdateChecker.CurrentVersion} - {DateTime.Now:yyyy-MM-dd HH:mm:ss} ===");
                logWriter.Flush();
            }
            catch (Exception ex)
            {
                SafeLog($"[!] Log file creation failed: {ex.Message}", errorColor);
            }
        }

        private void CloseLogFile()
        {
            try
            {
                lock (logWriter)
                {
                    logWriter?.WriteLine($"=== Session ended: {DateTime.Now:yyyy-MM-dd HH:mm:ss} ===");
                    logWriter?.Flush();
                    logWriter?.Dispose();
                    logWriter = null;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Log file close error: {ex.Message}");
            }
        }

        #endregion

        #region Config

        private void LoadConfig()
        {
            try
            {
                if (File.Exists(configFile))
                {
                    var json = File.ReadAllText(configFile);
                    var config = JsonSerializer.Deserialize<Dictionary<string, string>>(json);
                    if (config != null && config.ContainsKey("autoSpoof"))
                    {
                        bool.TryParse(config["autoSpoof"], out bool savedAutoSpoof);
                        autoSpoof = savedAutoSpoof;
                        if (autoSpoofToggle != null)
                            autoSpoofToggle.SetChecked(autoSpoof);
                        SafeLog($"[*] Config loaded: AutoSpoof = {autoSpoof}", accentColor);
                    }
                }
            }
            catch (Exception ex)
            {
                SafeLog($"[!] Config load failed: {ex.Message}", errorColor);
            }
        }

        private void SaveConfig()
        {
            try
            {
                Directory.CreateDirectory(appDataFolder);
                var config = new Dictionary<string, string>
                {
                    ["autoSpoof"] = autoSpoof.ToString(),
                    ["lastRun"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };
                File.WriteAllText(configFile, JsonSerializer.Serialize(config));
            }
            catch (Exception ex)
            {
                SafeLog($"[!] Config save failed: {ex.Message}", errorColor);
            }
        }

        #endregion

        #region Operations

        private async Task DoSpoofAsync()
        {
            if (IsUpdateBlocking()) return;
            if (isSpoofing) return;
            isSpoofing = true;
            operationCts = new CancellationTokenSource(OperationTimeout);
            UpdateButtons();

            try
            {
                SafeUiInvoke(() =>
                {
                    if (!console.Visible) console.Show(this);
                    progressLabel.Visible = true;
                });
                StartLogFile();
                SpoofManager.Instance.Clear();

                int successCount = 0;
                int failCount = 0;
                int totalModules = modules.Length;

                for (int i = 0; i < modules.Length; i++)
                {
                    operationCts.Token.ThrowIfCancellationRequested();
                    int progressPercent = ((i + 1) * 100) / totalModules;
                    UpdateProgressLabel(progressPercent);
                    await Task.Delay(50, operationCts.Token);

                    var module = modules[i];
                    try
                    {
                        module.SetLogging(logProgress, successColor, errorColor, warnColor, operationCts);
                        await Task.Run(() => module.ExecuteAsync(), operationCts.Token);

                        if (module.ErrorCount == 0)
                        {
                            SafeLog($"[+] {module.Name}", successColor);
                            successCount++;
                        }
                        else if (module.SpoofCount > 0)
                        {
                            SafeLog($"[!] {module.Name} (partial)", warnColor);
                            successCount++;
                        }
                        else
                        {
                            SafeLog($"[-] {module.Name} (failed)", errorColor);
                            failCount++;
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        SafeLog("[!] Operation cancelled during module execution", warnColor);
                        throw;
                    }
                    catch (Exception ex)
                    {
                        SafeLog($"[-] {module.Name}: {ex.Message}", errorColor);
                        failCount++;
                    }
                }

                UpdateProgressLabel(90);
                await Task.Delay(50);
                SaveBackup();
                SafeLog($"Done: {successCount} success, {failCount} failed", failCount > 0 ? warnColor : successColor);
                UpdateProgressLabel(100);
                await Task.Delay(200);
            }
            catch (OperationCanceledException)
            {
                SafeLog("[!] Operation cancelled", warnColor);
            }
            catch (Exception ex)
            {
                SafeLog($"[!] Fatal error: {ex.Message}", errorColor);
                Logger.Debug(ex.ToString());
            }
            finally
            {
                CloseLogFile();
                isSpoofing = false;
                UpdateButtons();
                SafeUiInvoke(() => { progressLabel.Visible = false; });
                operationCts?.Dispose();
                operationCts = null;
            }
        }

        private void SaveBackup()
        {
            try
            {
                string json = SpoofManager.Instance.ExportBackup();
                if (json == null)
                {
                    SafeLog("[!] Failed to serialize backup", errorColor);
                    return;
                }

                Directory.CreateDirectory(Path.GetDirectoryName(backupFile) ?? ".");
                string tempFile = backupFile + ".tmp";
                File.WriteAllText(tempFile, json);
                if (File.Exists(backupFile)) File.Delete(backupFile);
                File.Move(tempFile, backupFile);
            }
            catch (Exception ex)
            {
                SafeLog($"[!] Backup save failed: {ex.Message}", errorColor);
            }
        }

        private async Task DoRemoveBanTracesAsync()
        {
            if (IsUpdateBlocking()) return;
            if (isSpoofing)
            {
                SafeLog("[!] Another operation is already running", warnColor);
                return;
            }

            isSpoofing = true;
            operationCts = new CancellationTokenSource(OperationTimeout);
            UpdateButtons();

            try
            {
                SafeUiInvoke(() =>
                {
                    if (!console.Visible) console.Show(this);
                    progressLabel.Visible = true;
                });
                StartLogFile();

                UpdateProgressLabel(10);
                await Task.Delay(50, operationCts.Token);

                var cleaner = new BanTracesCleaner();
                await Task.Run(async () =>
                {
                    cleaner.SetLogging(logProgress, successColor, errorColor, warnColor, operationCts);
                    await cleaner.ExecuteAsync();
                }, operationCts.Token);

                UpdateProgressLabel(100);
                await Task.Delay(200);

                SafeLog("[+] Ban Trace Removal complete!");
            }
            catch (OperationCanceledException)
            {
                SafeLog("[!] Operation cancelled", warnColor);
            }
            catch (Exception ex)
            {
                SafeLog($"[!] Error: {ex.Message}", errorColor);
            }
            finally
            {
                CloseLogFile();
                isSpoofing = false;
                UpdateButtons();
                SafeUiInvoke(() => { progressLabel.Visible = false; });
                operationCts?.Dispose();
                operationCts = null;
            }
        }

        private async Task DoRevertAsync()
        {
            if (IsUpdateBlocking()) return;
            if (isSpoofing)
            {
                SafeLog("[!] Cannot revert while spoofing!", warnColor);
                return;
            }

            isSpoofing = true;
            operationCts = new CancellationTokenSource(OperationTimeout);
            UpdateButtons();

            try
            {
                SafeUiInvoke(() =>
                {
                    if (!console.Visible) console.Show(this);
                    progressLabel.Visible = true;
                });
                StartLogFile();

                UpdateProgressLabel(10);
                await Task.Delay(50, operationCts.Token);

                var revertModule = new RevertModule(
                    logProgress,
                    successColor,
                    errorColor,
                    warnColor,
                    backupFile);

                var result = await Task.Run(() => revertModule.ExecuteAsync(operationCts.Token), operationCts.Token);

                switch (result.Status)
                {
                    case RevertStatus.NoBackup:
                        SafeLog("[~] Nothing to revert - already restored or never spoofed", warnColor);
                        break;
                    case RevertStatus.Empty:
                        SafeLog("[!] Backup file was empty or invalid", warnColor);
                        break;
                    case RevertStatus.PartialSuccess:
                        SafeLog($"[!] Partially reverted: {result.RestoredCount} restored, {result.FailedCount} failed", warnColor);
                        break;
                    case RevertStatus.Success:
                        SafeLog($"[+] Successfully reverted {result.RestoredCount} values", successColor);
                        break;
                }

                UpdateProgressLabel(100);
                await Task.Delay(200);
            }
            catch (OperationCanceledException)
            {
                SafeLog("[!] Revert cancelled", warnColor);
            }
            catch (Exception ex)
            {
                SafeLog($"[!] Revert failed: {ex.Message}", errorColor);
            }
            finally
            {
                SpoofManager.Instance.Clear();
                CloseLogFile();
                isSpoofing = false;
                UpdateButtons();
                SafeUiInvoke(() => { progressLabel.Visible = false; });
                operationCts?.Dispose();
                operationCts = null;
            }
        }

        #endregion

        #region Helpers

        private void UpdateButtons()
        {
            if (InvokeRequired)
            {
                SafeUiInvoke((Action)UpdateButtons);
                return;
            }
            spoofButton.SetSpoofing(isSpoofing);
            revertButton.SetSpoofing(isSpoofing);
            spoofButton.Text = isSpoofing ? "SPOOFING..." : "SPOOF ALL";
        }

        private void SafeUiInvoke(Action action)
        {
            try
            {
                if (IsHandleCreated && InvokeRequired)
                    BeginInvoke(action);
                else
                    action();
            }
            catch (InvalidOperationException)
            {
                Debug.WriteLine($"UI invoke failed: handle not created");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"UI invoke error: {ex.Message}");
            }
        }

        private void UpdateProgressLabel(int percent)
        {
            if (progressLabel == null) return;

            if (InvokeRequired)
            {
                BeginInvoke(new Action(() => UpdateProgressLabel(percent)));
                return;
            }

            progressLabel.Text = $"Progress: {percent}%";
            progressLabel.Visible = percent > 0 && percent < 100;
            progressLabel.Refresh();
        }

        private void CreateStartMenuShortcutOnce()
        {
            string shortcutPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.StartMenu),
                "Programs", "Fallen Spoofer.lnk");

            if (File.Exists(shortcutPath)) return;

            CreateStartMenuShortcut();
        }

        private void CreateStartMenuShortcut()
        {
            try
            {
                string exePath = Application.ExecutablePath;
                string shortcutPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.StartMenu),
                    "Programs", "Fallen Spoofer.lnk");

                try
                {
                    if (File.Exists(shortcutPath)) File.Delete(shortcutPath);
                }
                catch (Exception ex)
                {
                    Logger.Debug($"Old shortcut delete error: {ex.Message}");
                }

                Type shellType = Type.GetTypeFromProgID("WScript.Shell");
                if (shellType == null) return;

                dynamic shell = Activator.CreateInstance(shellType);
                dynamic shortcut = shell.CreateShortcut(shortcutPath);
                shortcut.TargetPath = exePath;
                shortcut.WorkingDirectory = Path.GetDirectoryName(exePath);
                shortcut.Description = $"Fallen Spoofer v{AutoUpdateChecker.CurrentVersion} - Hardware ID Spoofer";
                shortcut.Save();
                SafeLog("[+] Start Menu shortcut updated");
            }
            catch (Exception ex)
            {
                Logger.Debug($"Shortcut creation error: {ex.Message}");
            }
        }

        #endregion

        [DllImport("shell32.dll")] static extern bool IsUserAnAdmin();
        private bool IsAdmin() { try { return IsUserAnAdmin(); } catch { return false; } }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.ThreadException += (s, e) =>
            {
                Logger.Debug($"Thread exception: {e.Exception}");
                SafeMessageBox(
                    $"Fatal error:\n\n{e.Exception.Message}\n\nStack trace:\n{e.Exception.StackTrace}",
                    "Fallen Spoofer Error");
            };

            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                var ex = e.ExceptionObject as Exception;
                Logger.Debug($"Unhandled exception: {ex}");
                SafeMessageBox(
                    $"Fatal error:\n\n{ex?.Message}\n\nStack trace:\n{ex?.StackTrace}",
                    "Fallen Spoofer Error");
            };

            Application.Run(new MainForm());
        }

        private static void SafeMessageBox(string message, string title)
        {
            try
            {
                Task.Run(() =>
                {
                    MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
                });
            }
            catch
            {
                Debug.WriteLine($"Cannot show message box: {message}");
            }
        }
    }

    public static class NativeMethods
    {
        [DllImport("user32.dll")] public static extern bool ReleaseCapture();
        [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wp, IntPtr lp);
    }
}
