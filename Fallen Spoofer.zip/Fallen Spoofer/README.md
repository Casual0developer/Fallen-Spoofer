# Fallen Spoofer v1.0.8

A comprehensive hardware ID spoofer for Windows with a clean dark UI.

## Spoofing Categories

| Tab | Spoofs |
|-----|--------|
| **MAC Address** | Physical MAC of any network adapter |
| **User Account** | Local Windows user profile name |
| **Device Name** | Computer name + NetBIOS name |
| **Disk / RAM / GPU** | Disk serials (HDD/SSD/NVMe), VolumeID, RAM serials, GPU serials |
| **HWID / Registry** | MachineGuid, BuildGUID, registry IDs, TPM |
| **NetBIOS / ARP / PnP / Mon** | ARP cache, PnP devices, monitor EDID serials, NVIDIA UUID |
| **USB** | USB controller and device identifiers |
| **Memory** | RAM module identifiers and memory management data |
| **VBS** | Virtualization-Based Security identifiers |
| **Spoof All** | Everything above in one click |

## Requirements

- Windows OS (7, 8, 10, 11)
- Administrator privileges
- .NET 8.0 runtime (self-contained build includes it)

## Usage

### Option 1: Direct
Run **Fallen Spoofer.exe** directly (self-contained, no .NET Runtime needed).

### After Launching
1. Run **as Administrator**
2. Click **SPOOF ALL** or **Remove Ban Traces**
3. Confirm the action
4. Use **REVERT** to restore original values

## Build

```batch
cd csharp
dotnet publish -c Release --self-contained true -r win-x64 -p:PublishSingleFile=true -o ../Release_v15
```

Output: `Release_v15\Fallen Spoofer.exe`

## Safety Features

- **Ban Trace Cleaner**: Removes known game/anti-cheat logs (Fortnite, VALORANT, EAC, BattlEye, Steam, Epic). Does NOT touch Windows system files, drivers, temp files, or event logs.
- **Registry Spoofing**: Only modifies registry keys that actually exist on the system — no creation of fake/bogus registry paths.
- **Revert**: All original values are backed up before modification and can be restored. Backup preserved if revert fails.

## How It Works

Fallen Spoofer modifies Windows registry keys that store hardware identifiers used by anti-cheat systems for HWID (Hardware ID) bans. By randomizing these identifiers, the system appears as a different machine to anti-cheat software.

### Registry Locations Modified

- `HARDWARE\DESCRIPTION\System\` - CPU, motherboard, BIOS identifiers
- `SYSTEM\CurrentControlSet\Enum\` - USB, PCI device identifiers
- `SYSTEM\CurrentControlSet\Control\Class\` - Network adapter, GPU identifiers
- `SOFTWARE\Microsoft\Cryptography\` - Machine GUID, TPM identifiers
- `SOFTWARE\Microsoft\Windows NT\CurrentVersion\` - Windows product ID, install date

### Revert Functionality

All original registry values are backed up to `%APPDATA%\FallenSpoofer\backup.json` before any modifications. The REVERT operation restores all original values from this backup.
